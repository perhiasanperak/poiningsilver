package com.ingsilver.is_poin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
