package is_poin.is_poin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
