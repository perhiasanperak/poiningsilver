import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:is_poin/src/ui/splash_screen/splash_screen_page.dart';
import 'package:package_info_plus/package_info_plus.dart';

// void main() => runApp(App());
Future<void> fcmBackgroundHandler(RemoteMessage message) async {
  // print("Handling a background message: ${message.messageId}");
  // print(message.notification!.title);
}

void main() async {
  //? to make sure that firebase initialized
  PackageInfo packageInfo = await PackageInfo.fromPlatform();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await requestPermission();
  FirebaseMessaging.onBackgroundMessage(fcmBackgroundHandler);
  if (!kIsWeb) {
    FirebaseMessaging.instance.subscribeToTopic('all');
  }
  runApp(
    MaterialApp(
        title:
            (!kIsWeb) ? "Point IS" : "Point IS - Web v${packageInfo.version}",
        home: SplashScreenPage(),
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: Colors.black,
          accentColor: Colors.black,
        )),
  );
}

Future<void> requestPermission() async {
  FirebaseMessaging messaging = FirebaseMessaging.instance;

  NotificationSettings settings = await messaging.requestPermission(
    alert: true,
    announcement: false,
    badge: true,
    carPlay: false,
    criticalAlert: false,
    provisional: false,
    sound: true,
  );

  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
    print('User granted permission: ${settings.authorizationStatus}');
  } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
    print('User granted provisional permission');
  } else {
    print("User declined or has not accepted permission");
  }
}
