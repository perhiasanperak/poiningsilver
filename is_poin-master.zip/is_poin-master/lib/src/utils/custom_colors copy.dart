import 'package:flutter/rendering.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CustomColors {
  Color? gradColor,
      themeColor,
      backgroundColor,
      listItemCard,
      textColorHighlight;
  bool? _darkMode;

  getPref() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    _darkMode = preferences.getBool("dark_mode");
  }

  void checkDayTime(bool darkModeIsEnabled) {
    getPref();
    bool _day = false;
    print("Dark Mode: $_darkMode");
    if (darkModeIsEnabled == false) {
      gradColor = const Color(0xFF94B6FF);
      themeColor = const Color(0xFF00CCFF);
      backgroundColor = const Color(0xFFE9E9E9);
      listItemCard = const Color(0xFFFFFFFF);
      textColorHighlight = const Color(0xFF000000);
    } else {
      gradColor = const Color(0xFF0C54F0);
      themeColor = const Color(0xFF000000);
      backgroundColor = const Color(0xFF000847);
      listItemCard = const Color(0xFF9B9B9B).withOpacity(0.5);
      textColorHighlight = const Color(0xFFFFFFFF);
    }
  }
}
