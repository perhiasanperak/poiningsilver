import 'package:flutter/rendering.dart';

class CustomColors {
  Color gradColor = const Color(0xFF94B6FF);
  Color themeColor = const Color(0xFF00CCFF);
  Color backgroundColor = const Color(0xFFE9E9E9);
  Color listItemCard = const Color(0xFFFFFFFF);
  Color textColorHighlight = const Color(0xFF000000);
}
