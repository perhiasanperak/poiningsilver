import 'dart:convert';

import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';
// import 'package:toast/toast.dart';

class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  String? id_pos, password, dateBirth, confirmPassword, email, telepon, nama;
  final dateBirthController = TextEditingController();
  final _key = new GlobalKey<FormState>();

  bool _secureText = true;
  bool _secureTextCP = true;

  showHide() {
    setState(() {
      _secureText = !_secureText;
    });
  }

  showHideCP() {
    setState(() {
      _secureTextCP = !_secureTextCP;
    });
  }

  check() {
    final form = _key.currentState!;
    if (form.validate()) {
      form.save();
      register();
    }
  }

  register() async {
    final response = await http
        .post(Uri.parse("http://192.168.1.52:8080/api/register.php"), body: {
      "id_pos": id_pos,
      "nama": nama!.toUpperCase(),
      "birthday": dateBirth,
      "telepon": telepon,
      "email": email,
      "password": password,
      "confirmPass": confirmPassword,
    });
    final data = jsonDecode(response.body);
    int? value = data['value'];
    String? pesan = data['message'];
    String? namaAPI = data['nama'];
    String? id = data['id'];
    print("nama $namaAPI");
    if (value == 1) {
      print(pesan);
      // Toast.show(pesan, context,
      //     duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
      Navigator.pop(context);
    } else {
      print(pesan);
      // Toast.show(pesan, context,
      //     duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  // void showSnackBar(String msg) {
  //   Scaffold.of(context).showSnackBar(new SnackBar(content: new Text(msg)));
  // }

  // DateTime selectedDate = DateTime.now();
  // Future<Null> _selectDate(BuildContext context) async {
  //   final DateTime picked = await showDatePicker(
  //       context: context,
  //       initialDate: selectedDate,
  //       firstDate: DateTime(1945, 8),
  //       lastDate: DateTime(2100));
  //   if (picked != null && picked != selectedDate) {
  //     setState(() {
  //       selectedDate = picked;
  //     });
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    final snackBar = SnackBar(
      content: Text('teeeeeeessstttt'),
    );
    return Scaffold(
      appBar: AppBar(
        title: Text("Register"),
      ),
      body: new Form(
        key: _key,
        child: Center(
          // padding: EdgeInsets.all(16.0),
          child: ListView(
            // shrinkWrap: true,
            padding: EdgeInsets.all(16.0),
            // mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                height: 200,
                child: Image.asset("assets/images/logo_is.png"),
              ),
              TextFormField(
                validator: (e) {
                  if (e!.isEmpty) {
                    return "Please insert No Customer IS";
                  }
                },
                onSaved: (e) => id_pos = e,
                autofocus: false,
                // initialValue: 'kevin laurence',
                decoration: InputDecoration(
                  hintText: 'ID Customer IS : 0xxx',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(32.0)),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              TextFormField(
                validator: (e) {
                  if (e!.isEmpty) {
                    return "Please insert Nama";
                  }
                },
                onSaved: (e) => nama = e,
                autofocus: false,
                // initialValue: 'kevin laurence',
                decoration: InputDecoration(
                  hintText: 'Nama',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(32.0)),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              // RaisedButton(
              //   onPressed: () => _selectDate(context),
              //   child: Text("${selectedDate.toLocal()}".split(' ')[0]),
              // ),
              TextFormField(
                // onTap: () => _selectDate(context),
                // initialValue: "$selectedDate.toLocal()".split(' ')[0],
                validator: (e) {
                  if (e!.isEmpty) {
                    return "Please insert Birthday";
                  }
                },
                controller: dateBirthController,
                decoration: InputDecoration(
                  hintText: 'Birthday',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(32.0)),
                ),
                onTap: () async {
                  DateTime selectedDate = DateTime.now();
                  FocusScope.of(context).requestFocus(new FocusNode());
                  final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: selectedDate,
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2100));
                  dateBirthController.text = picked.toString().split(' ')[0];
                  dateBirth = dateBirthController.text.toString();
                },
              ),
              SizedBox(height: 8.0),
              TextFormField(
                validator: (e) {
                  if (e!.isEmpty) {
                    return "Please insert Telepon";
                  }
                },
                onSaved: (e) => telepon = e,
                autofocus: false,
                keyboardType: TextInputType.number,
                // initialValue: '08782748343',
                decoration: InputDecoration(
                  hintText: 'Telepon : 08xxx',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(32.0),
                  ),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              TextFormField(
                validator: (e) {
                  if (e!.isEmpty) {
                    return "Please insert Email";
                  }
                },
                onSaved: (e) => email = e,
                autofocus: false,
                // initialValue: 'heathscliff334@gmail.com',
                decoration: InputDecoration(
                  hintText: 'Email',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(32.0),
                  ),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              TextFormField(
                validator: (e) {
                  if (e!.isEmpty) {
                    return "Please insert Password";
                  }
                },
                onSaved: (e) => password = e,
                autofocus: false,
                obscureText: _secureText,
                // initialValue: 'kevin',
                decoration: InputDecoration(
                  hintText: 'Password',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(32.0)),
                  suffixIcon: IconButton(
                    onPressed: showHide,
                    icon: Icon(
                        _secureText ? Icons.visibility_off : Icons.visibility),
                  ),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              TextFormField(
                validator: (e) {
                  if (e!.isEmpty) {
                    return "Please insert Confirm Password";
                  }
                },
                onSaved: (e) => confirmPassword = e,
                autofocus: false,
                obscureText: _secureTextCP,
                // initialValue: 'kevin',
                decoration: InputDecoration(
                  hintText: 'Confirm Password',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(32.0),
                  ),
                  suffixIcon: IconButton(
                    onPressed: showHideCP,
                    icon: Icon(_secureTextCP
                        ? Icons.visibility_off
                        : Icons.visibility),
                  ),
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Material(
                  borderRadius: BorderRadius.circular(32.0),
                  shadowColor: Colors.black,
                  elevation: 5.0,
                  child: MaterialButton(
                    minWidth: 200.0,
                    height: 42.0,
                    onPressed: () {
                      print('telp : $telepon');
                      check();
                      // Scaffold.of(context).showSnackBar(new SnackBar(
                      //     content: new Text("TEEEEEESSSSTTT")));
                    },
                    color: Colors.black,
                    child:
                        Text('Register', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              FlatButton(
                child: Text(
                  "Lupa ID Customer? Klik disini",
                  style: TextStyle(color: Colors.black54),
                ),
                onPressed: () {
                  // Navigator.push(context, MaterialPageRoute(builder: (context) {
                  //   return Register();
                  // }));
                  // ? Isi dengan forgotId_page.dart
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
