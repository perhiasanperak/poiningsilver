import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/ui/forgot/forgot_page.dart';

import 'package:is_poin/src/ui/profile/profile_view_page.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:is_poin/src/app.dart';
// import 'package:toast/toast.dart';
import 'package:is_poin/src/ui/login/register_page.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

enum LoginStatus { notSignIn, signIn }

class _LoginState extends State<Login> {
  LoginStatus _loginStatus = LoginStatus.notSignIn;
  int? isRemember = 0;
  String? telp, password, name, email, idUser;
  ApiService apiService = ApiService();
  final _key = new GlobalKey<FormState>();

  Dio _dio = new Dio();
  bool isLoading = false;
  bool _secureText = true;

  bool? rememberMe = false;

  check() {
    final form = _key.currentState!;
    if (form.validate()) {
      form.save();
      login();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  login() async {
    int timeout = 20;
    String errorTitle = "";
    String errorMsg = "";
    try {
      final response = await http
          .post(Uri.parse("${apiService.apiUrl}login.php"), body: {
        "telp": telp,
        "password": password
      }).timeout(Duration(seconds: timeout));
      final data = jsonDecode(response.body);
      int? value = data['value'];
      String? pesan = data['message'];
      String? telpAPI = data['telp'];
      String? namaHome = data['nama_cst_home'];
      print(namaHome);
      String? namaAPI = data['nama_cst'];
      print(namaAPI);
      String? id = data['id'];
      String? emailAPI = data['email'];
      String? idIpos = data['id_ipos'];
      String? nameIpos = data['nama_ipos'];
      String? fullName = data['fullName'];
      String? city = data['kota'];
      String? birthday = data['birthday'];
      String? birthdayTemp = data['birthdayTemp'];
      String? expPoin = data['exp_poin'];
      String? expPoinTemp = data['exp_poinTemp'];
      String? rpPoin = data['rp_poin'];
      int? expCount = data['selisih_exp'];
      // String profilePicture = data['profile_picture'];
      print(data);
      // print("nama $namaAPI");
      if (value == 1) {
        setState(() {
          _loginStatus = LoginStatus.signIn;
          savePref(
            value,
            telpAPI,
            namaHome,
            namaAPI,
            fullName,
            emailAPI,
            id,
            password,
            idIpos,
            nameIpos,
            city,
            birthday,
            birthdayTemp,
            expPoin,
            expPoinTemp,
            rpPoin,
            expCount,
            // profilePicture
          );
        });
        print(pesan);
        // Toast.show(pesan, context,
        //     duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
      } else {
        print(pesan);
        showDialog(
            context: context,
            builder: (BuildContext context) => CupertinoAlertDialog(
                  title: new Text("Error"),
                  content: new Text(pesan!),
                  actions: <Widget>[
                    CupertinoDialogAction(
                      // isDefaultAction: false,
                      child: Text("Close"),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ));
        setState(() {
          isLoading = false;
        });
      }
    } on TimeoutException catch (e) {
      print('Timeout Error: $e');
      errorTitle = "Connection Timeout";
      errorMsg =
          "The connection has timed out, app server took too long to respond. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg);
      setState(() {
        isLoading = false;
      });
    } on SocketException catch (e) {
      print('Socket Error: $e');
      errorTitle = "Socket Error";
      errorMsg =
          "A socket error occurred during connecting the server. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg);
      setState(() {
        isLoading = false;
      });
    }
    // on Error catch (e) {
    //   print('General Error: $e');
    // }
  }

  Future customDialog(String errorTitle, String errorMsg) {
    return showDialog(
        context: context,
        builder: (BuildContext context) => CupertinoAlertDialog(
              title: new Text(errorTitle),
              content: new Text(errorMsg),
              actions: <Widget>[
                CupertinoDialogAction(
                  // isDefaultAction: false,
                  child: Text("Close"),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ));
  }

  savePref(
    int? value,
    String? telp,
    String? namaHome,
    String? nama,
    String? fullName,
    String? email,
    String? id,
    String? pwd,
    String? idIpos,
    String? nameIpos,
    String? city,
    String? birthday,
    String? birthdayTemp,
    String? expPoin,
    String? expPoinTemp,
    String? rpPoin,
    int? expCount,
    // String profilePicture
  ) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      preferences.setInt("value", value!);
      preferences.setString("nama_home", namaHome!);
      preferences.setString("nama", nama!);
      preferences.setString("fullName", fullName!);
      preferences.setString("telp", telp!);
      preferences.setString("password", password!);
      preferences.setInt("remember", isRemember!);
      preferences.setString("email", email!);
      preferences.setString("id", id!);
      preferences.setString("idIpos", idIpos!);
      preferences.setString("namaIpos", nameIpos!);
      preferences.setString("kota", city!);
      preferences.setString("birthday", birthday!);
      preferences.setString("birthdayRaw", birthdayTemp!);
      preferences.setString("expPoin", expPoin!);
      preferences.setString("expPoinRaw", expPoinTemp!);
      preferences.setString("rpPoin", rpPoin!);
      preferences.setInt("expCount", expCount!);
      // preferences.setString("profilePicture", profilePicture);
      // if(pwd != null){
      //   preferences.setString("id", id);
      // }
      preferences.commit();
    });
    name = preferences.getString("nama");
    email = preferences.getString("email");
    idUser = preferences.getString("id");
  }

  var value;
  getPref() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      value = preferences.getInt("value");
      telp = preferences.getString("telp");
      name = preferences.getString("nama");
      isRemember = preferences.getInt("remember");
      password = preferences.getString("password");
      idUser = preferences.getString("id");
      _loginStatus = value == 1 ? LoginStatus.signIn : LoginStatus.notSignIn;
    });
  }

  void signOut() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      preferences.setInt("value", 0);

      preferences.commit();
      _loginStatus = LoginStatus.notSignIn;
    });
  }

  @override
  void initState() {
    super.initState();
    getPref();
    // getRememberPref();
  }

  @override
  Widget build(BuildContext context) {
    // print("password (login page-widget) : $password");
    switch (_loginStatus) {
      case LoginStatus.notSignIn:
        return Scaffold(
          // appBar: AppBar(
          //   title: Text("IS CPOINT"),
          // ),
          body: Stack(
            children: [
              Container(
                width: double.infinity,
                height: double.infinity,
                // color: Colors.grey[200],
                child: Image.network(
                    // "https://wallpaperaccess.com/full/790994.jpg",
                    "https://i.pinimg.com/originals/cb/20/4f/cb204fb8838467b69ab17b7433069aa3.jpg",
                    fit: BoxFit.cover),
                // child: Image.asset(
                //   "assets/images/background.png",
                //   fit: BoxFit.cover,
                // ),
              ),
              // Container(
              //   width: double.infinity,
              //   height: 100,
              //   padding: EdgeInsets.only(bottom: 10),
              //   decoration: BoxDecoration(
              //       // color: Colors.blue[200],
              //       gradient: LinearGradient(
              //         colors: [
              //           const Color(0xFF94B6FF),
              //           const Color(0xFF00CCFF),
              //         ],
              //         begin: const FractionalOffset(0.0, 1.0),
              //         end: const FractionalOffset(1.0, 0.0),
              //         stops: [0.0, 1.0],
              //         tileMode: TileMode.clamp,
              //       ),
              //       borderRadius: BorderRadius.only(
              //           bottomLeft: Radius.circular(30),
              //           bottomRight: Radius.circular(30))),
              //   child: Column(
              //     children: [
              //       Spacer(),
              //       Center(
              //           child: Text(
              //         "LOGIN",
              //         style: TextStyle(
              //             color: Colors.white,
              //             fontWeight: FontWeight.bold,
              //             fontSize: 32),
              //       )),
              //     ],
              //   ),
              // ),
              Container(
                width: double.infinity,
                height: double.infinity,
                color: Colors.transparent,
                child: Form(
                  key: _key,
                  child: Container(
                    // color: Colors.grey[200],
                    child: Center(
                      child: ListView(
                        shrinkWrap: true,
                        padding: EdgeInsets.all(16.0),
                        children: <Widget>[
                          Hero(
                            tag: 'hero',
                            child: CircleAvatar(
                              backgroundColor: Colors.grey[200],
                              radius: 100,
                              child: Image.asset("assets/images/logo_is.png"),
                            ),
                          ),
                          SizedBox(height: 15),
                          Container(
                            padding: EdgeInsets.all(15),
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(20)),
                            child: Column(
                              children: [
                                TextFormField(
                                  validator: (e) {
                                    if (e!.isEmpty) {
                                      return "Please insert phone";
                                    }
                                  },
                                  onSaved: (e) => telp = e,
                                  key: Key(telp!),
                                  initialValue: telp,
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                      hintText: 'Phone Number',
                                      contentPadding: EdgeInsets.fromLTRB(
                                          20.0, 10.0, 20.0, 10.0),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      prefixIcon: Icon(Icons.phone_outlined)),
                                ),
                                SizedBox(height: 8.0),
                                StatefulBuilder(builder: (BuildContext context,
                                    StateSetter setPasswordState) {
                                  return TextFormField(
                                    validator: (e) {
                                      if (e!.isEmpty) {
                                        return "Please insert password";
                                      }
                                    },
                                    onSaved: (e) => password = e,
                                    autofocus: false,
                                    obscureText: _secureText,
                                    key: Key(password!),
                                    initialValue: password,
                                    decoration: InputDecoration(
                                      hintText: 'Password',
                                      contentPadding: EdgeInsets.fromLTRB(
                                          20.0, 10.0, 20.0, 10.0),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      prefixIcon: Icon(Icons.lock_open),
                                      suffixIcon: IconButton(
                                        // onPressed: showHide,
                                        onPressed: () {
                                          setPasswordState(() {
                                            _secureText = !_secureText;
                                          });
                                        },
                                        icon: Icon(_secureText
                                            ? Icons.visibility_off
                                            : Icons.visibility),
                                      ),
                                    ),
                                  );
                                }),
                                SizedBox(height: 8.0),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: StatefulBuilder(builder:
                                          (BuildContext context,
                                              StateSetter setRememberState) {
                                        return Container(
                                          width: 10,
                                          child: CheckboxListTile(
                                            contentPadding: EdgeInsets.all(0),
                                            title: Text(
                                              "Remember me",
                                              style: TextStyle(fontSize: 14),
                                            ),
                                            value: (isRemember == 1)
                                                ? true
                                                : rememberMe,
                                            onChanged: (bool? newValue) {
                                              setRememberState(() {
                                                rememberMe = newValue;

                                                if (rememberMe!) {
                                                  print("true");
                                                  isRemember = 1;
                                                } else {
                                                  print("false");
                                                  isRemember = 0;
                                                }
                                              });
                                            },
                                            activeColor: Colors.blue[200],
                                            controlAffinity:
                                                ListTileControlAffinity.leading,
                                          ),
                                        );
                                      }),
                                    ),
                                    // Spacer(),
                                    FlatButton(
                                      child: Text(
                                        "Forgot password?",
                                        style: TextStyle(color: Colors.black54),
                                      ),
                                      onPressed: () {
                                        // ? Isi dengan forgotId_page.dart
                                        // Navigator.of(context).push(MaterialPageRoute(
                                        //     builder: (context) => ForgotPage()));
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext context) =>
                                                CupertinoAlertDialog(
                                                  title:
                                                      new Text("Coming Soon"),
                                                  content: new Text(
                                                      "This feature is under development"),
                                                  actions: <Widget>[
                                                    CupertinoDialogAction(
                                                      // isDefaultAction: false,
                                                      child: Text("Close"),
                                                      onPressed: () {
                                                        Navigator.of(context)
                                                            .pop();
                                                      },
                                                    ),
                                                  ],
                                                ));
                                      },
                                    )
                                  ],
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(vertical: 16.0),
                                  child: Material(
                                    borderRadius: BorderRadius.circular(32.0),
                                    shadowColor: Colors.black,
                                    elevation: 5.0,
                                    child: (isLoading == true)
                                        ? _loadingButton()
                                        : _loginButton(context),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Padding(
                          //   padding: EdgeInsets.symmetric(vertical: 16.0),
                          //   child: Material(
                          //     borderRadius: BorderRadius.circular(32.0),
                          //     shadowColor: Colors.black,
                          //     elevation: 5.0,
                          //     child: MaterialButton(
                          //       minWidth: 200.0,
                          //       height: 42.0,
                          //       onPressed: () async {
                          //         // dynamic dataResponse;
                          //         // dataResponse = await _dio
                          //         //     .get("https://reqres.in/api/users?page=2");
                          //         // print(dataResponse);
                          //         Navigator.of(context).push(MaterialPageRoute(
                          //             builder: (context) => TestBackground()));
                          //       },
                          //       color: Colors.black,
                          //       child: Text('TEST IMAGE',
                          //           style: TextStyle(color: Colors.white)),
                          //     ),
                          //   ),
                          // ),
                          // Padding(
                          //   padding: EdgeInsets.symmetric(vertical: 16.0),
                          //   child: Material(
                          //     borderRadius: BorderRadius.circular(32.0),
                          //     shadowColor: Colors.black,
                          //     elevation: 5.0,
                          //     child: MaterialButton(
                          //       minWidth: 200.0,
                          //       height: 42.0,
                          //       onPressed: () async {
                          //         // final response = await http
                          //         //     .get("https://reqres.in/api/users?page=2");
                          //         // final data = jsonDecode(response.body);
                          //         // print(data);
                          //         // Navigator.of(context).push(MaterialPageRoute(
                          //         //     builder: (context) => TestLazy()));
                          //         Navigator.of(context).push(
                          //             MaterialPageRoute(
                          //                 builder: (context) =>
                          //                     TestBackground()));
                          //       },
                          //       color: Colors.black,
                          //       child: Text('TEST',
                          //           style: TextStyle(color: Colors.white)),
                          //     ),
                          //   ),
                          // ),
                          // FlatButton(
                          //   child: Text(
                          //     "Don't have an account yet?",
                          //     style: TextStyle(color: Colors.black54),
                          //   ),
                          //   onPressed: () {
                          //     Navigator.push(context,
                          //         MaterialPageRoute(builder: (context) {
                          //       return Register();
                          //     }));
                          //   },
                          // ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
        break;
      case LoginStatus.signIn:

        // return App(signOut, name, telp, email, idUser);
        return App(signOut, idUser);

        break;
    }
  }

  MaterialButton _loginButton(BuildContext context) {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: () {
        setState(() {
          isLoading = true;
        });
        check();
      },
      color: Colors.black,
      child: Text('Login', style: TextStyle(color: Colors.white)),
    );
  }

  MaterialButton _loadingButton() {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: null,
      color: Colors.black,
      // child: CircularProgressIndicator(),
      child: CupertinoActivityIndicator(),
    );
  }
}
