// ignore_for_file: must_be_immutable

import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:http/http.dart' as _http;

import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/ui/login/login_page.dart';
import 'package:is_poin/src/ui/profile/about_page.dart';
import 'package:is_poin/src/ui/profile/change_password_page.dart';
import 'package:is_poin/src/ui/profile/edit_profile_page.dart';
import 'package:is_poin/src/ui/profile/view_picture.dart';
import 'package:is_poin/src/utils/custom_colors.dart';
import 'package:is_poin/src/widgets/custom_toast_content_widget.dart';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'package:image_picker/image_picker.dart';

// import 'package:toast/toast.dart';

class ProfileViewPage extends StatefulWidget {
  String? idUser;
  // VoidCallback signOut;

  ProfileViewPage(this.idUser);
  @override
  _ProfileViewPageState createState() => _ProfileViewPageState();
}

class _ProfileViewPageState extends State<ProfileViewPage> {
  List<String> listItem = [
    "Customer Code",
    "IPOS Code",
    "IPOS Name",
    "Email",
    "Phone",
    "Date of Birth",
    "Expired Date",
  ];
  ApiService apiService = ApiService();
  File? _image;
  bool isLoading = false, imgLoading = false;
  int? isRemember, _expCount;
  String? password, telp;
  String? _idIPos,
      _rpPoin,
      _name,
      _fullName,
      _iposName,
      _birthday,
      _birthdayTemp,
      _email,
      _city,
      _expPoin,
      _totalTrans,
      _phone,
      _profilePicture;
  LoginStatus? _loginStatus;
  bool? _switchValue;
  CustomColors _customColor = CustomColors();

  getPref() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      _idIPos = preferences.getString("idIpos");
      _name = preferences.getString("nama");
      // print(_name);
      _fullName = preferences.getString("fullName");
      _city = preferences.getString("kota");
      _iposName = preferences.getString("namaIpos");
      _expPoin = preferences.getString("expPoin");
      // _rpPoin = preferences.getString("rpPoin");
      _email = preferences.getString("email");
      _phone = preferences.getString("telp");
      _birthday = preferences.getString("birthday");
      isRemember = preferences.getInt("remember");
      password = preferences.getString("password");
      telp = preferences.getString("telp");
      _switchValue = preferences.getBool("dark_mode");
      // _profilePicture = preferences.getString("profilePicture");
    });
    // print("Get Pref : $_profilePicture");
    print("Get Pref : $_fullName");
  }

  savePref(
      String? telp,
      String? nama,
      String? fullName,
      String? email,
      String? birthday,
      String? birthdayTemp,
      String? rpPoin,
      String? expPoin,
      String? profilePicture,
      int? expCount) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      preferences.setString("nama", nama!);
      preferences.setString("fullName", fullName!);
      preferences.setString("telp", telp!);
      preferences.setString("email", email!);
      preferences.setString("birthday", birthday!);
      preferences.setString("birthdayRaw", birthdayTemp!);
      preferences.setString("rpPoin", rpPoin!);
      preferences.setString("expPoin", expPoin!);
      preferences.setInt("expCount", expCount!);
      // preferences.setString("rpPoin", rpPoin);
      // preferences.setString("profilePicture", profilePicture);
      preferences.commit();
    });
  }

  Future getProfile() async {
    // imageCache.clear();
    PaintingBinding.instance!.imageCache!.clear();
    isLoading = true;
    final response = await _http.post(
        Uri.parse("${apiService.apiUrl}getProfile.php"),
        body: {"kode_cst": widget.idUser});
    final data = jsonDecode(response.body);
    int? value = data['value'];
    String? pesan = data['message'];
    _name = data['nama_cst'];
    _fullName = data['fullName'];
    _iposName = data['nama_ipos'];
    _birthday = data['birthday'];
    _birthdayTemp = data['birthdayTemp'];
    _email = data['email'];
    _phone = data['telp'];
    _city = data['kota'];
    _idIPos = data['id_ipos'];
    _rpPoin = data['rp_poin'];
    _expPoin = data['exp_poin'];
    _totalTrans = data['total_transaksi'];
    _profilePicture = data['profile_picture'];
    _expCount = data['selisih_exp'];
    // print(_profilePicture);
    // print(data);
    if (value == 1) {
      // print(pesan);
      savePref(_phone, _name, _fullName, _email, _birthday, _birthdayTemp,
          _rpPoin, _expPoin, _profilePicture, _expCount);
      isLoading = false;
    } else {
      print(pesan);
    }
    setState(() {});
    return _name;
  }

  savePicture() async {
    final response = await _http
        .post(Uri.parse("${apiService.apiUrl}savePicture.php"), body: {
      "kode_cst": widget.idUser,
      "image": _image != null
          ? 'data:image/png;base64,' + base64Encode(_image!.readAsBytesSync())
          : '',
    });
    final data = jsonDecode(response.body);
    String? _pesan = data['message'];
    int? valueResponse = data['value'];

    if (valueResponse == 1) {
      print(_pesan);
      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("Success"),
                content: new Text(_pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    // isDefaultAction: false,
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      imgLoading = false;
      imageCache!.clear();
      imageCache!.clearLiveImages();
      // modalViewPicture(context, imgLoading);
      // print(data);
    } else {
      print(_pesan);
      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("Error"),
                content: new Text(_pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    // isDefaultAction: false,
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
    }
    setState(() {
      getProfile();
    });
  }

  Future getImage(ImageSource media) async {
    final img = await ImagePicker()
        .pickImage(source: media, maxHeight: 500, maxWidth: 500);

    if (img != null) {
      setState(() {
        // _image = img; // << old version
        _image = File(img.path); //! new version
        savePicture();
        imgLoading = true;
      });
    } else {
      print("image null");
    }
  }

  void myAlert() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            title: Text('Please choose media to select'),
            content: Container(
              height: MediaQuery.of(context).size.height / 6,
              child: Column(
                children: <Widget>[
                  FlatButton(
                    onPressed: () {
                      Navigator.pop(context);
                      getImage(ImageSource.gallery);
                    },
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.image),
                        SizedBox(width: 10),
                        Text('From Gallery'),
                      ],
                    ),
                  ),
                  FlatButton(
                    onPressed: () {
                      Navigator.pop(context);
                      getImage(ImageSource.camera);
                    },
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.camera),
                        SizedBox(width: 10),
                        Text('From Camera'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  signOut() async {
    // print("password : $telp");
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      // print("Is Remember : ${preferences.getInt('remember')}");
      preferences.setInt("value", 0);
      if (isRemember == 0) {
        preferences.setString("password", "");
        // print("passssword : ${preferences.getString('password')}");
      }
      preferences.commit();
      _loginStatus = LoginStatus.notSignIn;
      // Toast.show("Berhasil logout", context,
      //     duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => Login()));
    });
  }

  _darkMode(bool _darkModeStatus) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      preferences.setBool("dark_mode", _darkModeStatus);
    });
    // Phoenix.rebirth(context);
  }

  @override
  void initState() {
    super.initState();
    getPref();
    getProfile();
    // imageCache.clear();
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    // print("Profile picture : $_profilePicture");
    return Stack(
      children: [
        Container(
          child: LiquidPullToRefresh(
            color: Colors.transparent,
            backgroundColor: _customColor.gradColor,
            springAnimationDurationInMilliseconds: 500,
            showChildOpacityTransition: false,
            onRefresh: () async {
              setState(() {
                isLoading = true;
              });
              getProfile();
            },
            child: Container(
              padding: EdgeInsets.only(top: 10, left: 10, right: 10),
              height: double.infinity,
              width: double.infinity,
              decoration:
                  BoxDecoration(borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  Container(
                    height: 220,
                    // margin: EdgeInsets.only(bottom: 5),
                    width: double.infinity,
                    // color: Colors.grey[200],
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: 110,
                          height: 110,
                          // padding: EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            color: Colors.grey[300],
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                                width: 2,
                                color: Colors.blue[200]!,
                                style: BorderStyle.solid),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black45,
                                  blurRadius: 5,
                                  spreadRadius: 1,
                                  offset: Offset(0, 1))
                            ],
                          ),
                          child: (imgLoading == true)
                              ? Container(
                                  // width: 10,
                                  // height: 10,
                                  child: CupertinoActivityIndicator(
                                  radius: 15,
                                ))
                              : (isLoading == true)
                                  ? Shimmer.fromColors(
                                      baseColor: Colors.white,
                                      highlightColor: Colors.grey[200]!,
                                      child: Icon(
                                        Icons.person,
                                        size: 100,
                                        color: Colors.white,
                                      ),
                                    )
                                  : (_profilePicture == null ||
                                          _profilePicture == '')
                                      // ? Image.asset("assets/images/person_circle.png")
                                      ? Icon(
                                          Icons.person,
                                          size: 100,
                                          color: Colors.white,
                                        )
                                      : GestureDetector(
                                          onTap: () {
                                            modalViewPicture(context, isLoading,
                                                _profilePicture);
                                          },
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            child: (!kIsWeb)
                                                ? Image(
                                                    image: NetworkImage(
                                                        "https://adminpoin.ingsilver.co.id/images/uploads/users_profile/$_profilePicture"),
                                                    fit: BoxFit.cover,
                                                    key: ValueKey(new Random()
                                                        .nextInt(100)),
                                                  )
                                                : Image.asset(
                                                    "assets/images/logo_apps.png"),
                                          ),
                                        ),
                        ),
                        SizedBox(height: 10),
                        Container(
                            // color: Colors.red,
                            child: (_name != null)
                                ? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Text(
                                        "${_name!.toUpperCase()}",
                                        // "TOKO PERAK REJEKI BERKAH",
                                        style: TextStyle(fontSize: 20),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                      SizedBox(height: 8),
                                      Text("${_city!.toUpperCase()}"),
                                    ],
                                  )
                                : Shimmer.fromColors(
                                    baseColor: Colors.white,
                                    highlightColor: Colors.grey[200]!,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 200,
                                          height: 20,
                                          color: Colors.grey[200],
                                        ),
                                        SizedBox(height: 8),
                                        Container(
                                          width: 180,
                                          height: 20,
                                          color: Colors.grey[200],
                                        ),
                                      ],
                                    ),
                                  ))
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30)),
                      border: Border.all(
                          width: 1,
                          color: Colors.grey[350]!,
                          style: BorderStyle.solid),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black45,
                            blurRadius: 10,
                            spreadRadius: 1,
                            offset: Offset(0, 6))
                      ],
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 5,
                          child: Container(
                              // width: double.minPositive,
                              // color: Colors.red,
                              child: (isLoading == true)
                                  ? Shimmer.fromColors(
                                      baseColor: Colors.grey[200]!,
                                      highlightColor: Colors.white,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Container(
                                            width: 120,
                                            height: 20,
                                            color: Colors.grey[200],
                                            // color: Colors.red,
                                          ),
                                          SizedBox(height: 7),
                                          Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.grey[200],
                                            // color: Colors.red,
                                          ),
                                        ],
                                      ),
                                    )
                                  : Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text("Total Transaction"),
                                        SizedBox(height: 7),
                                        Text(
                                          "$_totalTrans",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20),
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                        )
                                      ],
                                    )),
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border(
                                  right: BorderSide(color: Colors.grey[200]!))),
                        ),
                        Expanded(
                          flex: 5,
                          child: Container(
                              // width: double.minPositive,
                              // color: Colors.blue,
                              child: (isLoading == true)
                                  ? Shimmer.fromColors(
                                      baseColor: Colors.grey[200]!,
                                      highlightColor: Colors.white,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Container(
                                            width: 120,
                                            height: 20,
                                            color: Colors.grey[200],
                                            // color: Colors.red,
                                          ),
                                          SizedBox(height: 7),
                                          Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.grey[200],
                                            // color: Colors.red,
                                          ),
                                        ],
                                      ),
                                    )
                                  : Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text("Total Point"),
                                        SizedBox(height: 7),
                                        Text(
                                          "$_rpPoin Pts",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20),
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                        )
                                      ],
                                    )),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 10,
                    child: SingleChildScrollView(
                      child: Container(
                          // height: double.infinity,
                          width: double.infinity,
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 15),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border(
                                  top: BorderSide(color: Colors.grey[200]!))),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              (_idIPos != null)
                                  ? Container(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          ProfileItemDetail(
                                              "Customer Code", widget.idUser),
                                          ItemDivider(marginBtm: 10),
                                          ProfileItemDetail(
                                              "IPOS Code", _idIPos),
                                          ItemDivider(marginBtm: 10),
                                          ProfileItemDetail("IPOS Name",
                                              _iposName!.toUpperCase()),
                                          ItemDivider(marginBtm: 10),
                                          ProfileItemDetail("Email", _email),
                                          ItemDivider(marginBtm: 10),
                                          ProfileItemDetail("Phone", _phone),
                                          ItemDivider(marginBtm: 10),
                                          ProfileItemDetail(
                                              "Date of Birth", _birthday),
                                          ItemDivider(marginBtm: 10),
                                          ProfileItemDetail(
                                              "Expired Date", _expPoin),
                                          ItemDivider(marginBtm: 5),
                                        ],
                                      ),
                                    )
                                  : ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: listItem.length,
                                      itemBuilder: (context, i) => Container(
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Shimmer.fromColors(
                                                baseColor: Colors.grey[200]!,
                                                highlightColor: Colors.white,
                                                child: Container(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        "${listItem[i]}",
                                                        style: TextStyle(
                                                          fontSize: 15,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                      SizedBox(height: 10),
                                                      Container(
                                                        width: double.infinity,
                                                        height: 20,
                                                        color: Colors.grey[200],
                                                        // color: Colors.red,
                                                      ),
                                                    ],
                                                  ),
                                                )),
                                            ItemDivider(marginBtm: 5),
                                          ],
                                        ),
                                      ),
                                    ),
                              // SizedBox(height: 20),
                              // ItemDivider(marginBtm: 10),
                              Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: () {
                                    return settingsModal(context);
                                  },
                                  child: Container(
                                    height: 40,
                                    width: double.infinity,
                                    child: Center(
                                      child: Text(
                                        "Settings",
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: Colors.grey,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              ItemDivider(marginBtm: 5),
                              Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: () {
                                    // return AboutPage();
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => AboutPage()));
                                  },
                                  child: Container(
                                    height: 40,
                                    width: double.infinity,
                                    child: Center(
                                      child: Text(
                                        "About",
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: Colors.grey,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              ItemDivider(marginBtm: 5),
                              Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: () {
                                    signOut();
                                  },
                                  child: Container(
                                    height: 40,
                                    width: double.infinity,
                                    child: Center(
                                      child: Text(
                                        "Logout",
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: Colors.grey,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              ItemDivider(marginBtm: 5),
                              SizedBox(height: 30)
                            ],
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  settingsModal(BuildContext context) {
    // return showModalBottomSheet<void>(
    //     context: context,
    //     builder: (BuildContext context) {
    //       return Container(
    //           padding: EdgeInsets.symmetric(vertical: 10),
    //           color: Colors.white,
    //           width: MediaQuery.of(context).size.width,
    //           height: MediaQuery.of(context).size.height / 6,
    //           child: Container(
    //             child: Column(
    //               children: [
    //                 ItemDivider(marginBtm: 5),
    //                 Material(
    //                   color: Colors.transparent,
    //                   child: InkWell(
    //                     onTap: () {
    //                       Navigator.of(context).push(MaterialPageRoute(
    //                           builder: (context) => EditProfilePage()));
    //                     },
    //                     child: Container(
    //                       height: 40,
    //                       width: double.infinity,
    //                       child: Center(
    //                         child: Text(
    //                           "Edit Profile",
    //                           style:
    //                               TextStyle(fontSize: 18, color: Colors.grey),
    //                         ),
    //                       ),
    //                     ),
    //                   ),
    //                 ),
    //                 ItemDivider(marginBtm: 5),
    //                 Material(
    //                   color: Colors.transparent,
    //                   child: InkWell(
    //                     onTap: () {
    //                       Navigator.of(context).push(MaterialPageRoute(
    //                           builder: (context) =>
    //                               ChangePasswordPage(widget.idUser)));
    //                     },
    //                     child: Container(
    //                       height: 40,
    //                       width: double.infinity,
    //                       child: Center(
    //                         child: Text(
    //                           "Change Password",
    //                           style:
    //                               TextStyle(fontSize: 18, color: Colors.grey),
    //                         ),
    //                       ),
    //                     ),
    //                   ),
    //                 ),
    //                 Flexible(child: ItemDivider(marginBtm: 5)),
    //               ],
    //             ),
    //           ));
    //     });
    return showCupertinoModalPopup<void>(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        // title: const Text('Title'),
        // message: const Text('Message'),
        actions: <CupertinoActionSheetAction>[
          CupertinoActionSheetAction(
            child: const Text('Edit Profile'),
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => EditProfilePage(
                        idUser: widget.idUser,
                        name: _fullName,
                        email: _email,
                        phone: _phone,
                        birthday: _birthdayTemp,
                      )));
            },
          ),
          CupertinoActionSheetAction(
            child: const Text('Change Profile Picture'),
            onPressed: () {
              if (!kIsWeb) {
                Navigator.of(context).pop();
                myAlert();
              } else {
                showToastWidget(
                    CustomToastContentWidget(
                      context: context,
                      msg: "Please use mobile app version.",
                      type: "failed",
                      dynWidth: 1.5,
                    ),
                    context: context,
                    position: StyledToastPosition.center,
                    animation: StyledToastAnimation.scale,
                    reverseAnimation: StyledToastAnimation.scaleRotate,
                    duration: Duration(seconds: 3),
                    animDuration: Duration(seconds: 1),
                    curve: Curves.elasticOut,
                    reverseCurve: Curves.easeInOutBack);
              }

              // Navigator.of(context).push(MaterialPageRoute(
              //     builder: (context) => ChangePasswordPage(widget.idUser)));
            },
          ),
          CupertinoActionSheetAction(
            child: const Text('Change Password'),
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => ChangePasswordPage(widget.idUser)));
            },
          ),
          // CupertinoActionSheetAction(
          //     onPressed: () {},
          //     child: Row(
          //       mainAxisAlignment: MainAxisAlignment.center,
          //       children: [
          //         Text("Dark Mode"),
          //         SizedBox(width: 10),
          //         CupertinoSwitch(
          //             value: _switchValue,
          //             onChanged: (value) {
          //               setState(() {
          //                 Navigator.of(context).pop();
          //                 _switchValue = value;
          //                 print("Dark mode status: $_switchValue");
          //                 _darkMode(_switchValue);
          //                 // Phoenix.rebirth(context);
          //               });
          //             }),
          //       ],
          //     ))
        ],
      ),
    );
  }
}

class ItemDivider extends StatelessWidget {
  const ItemDivider({Key? key, required this.marginBtm}) : super(key: key);
  final double marginBtm;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: marginBtm),
      width: double.infinity,
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border(bottom: BorderSide(color: Colors.grey[200]!))),
    );
  }
}

class ProfileItemDetail extends StatelessWidget {
  ProfileItemDetail(this._itemTitle, this._iposName);
  final String _itemTitle;
  final String? _iposName;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "$_itemTitle",
            style: TextStyle(
              fontSize: 15,
              color: Colors.grey[400],
              // fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Text(
            "$_iposName",
            style: TextStyle(
              fontSize: 17,
              color: Colors.black,
              fontWeight: FontWeight.w400,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 2,
          ),
        ],
      ),
    );
  }
}
