import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

void modalViewPicture(
    BuildContext context, bool _isLoading, String? _profilePicture) {
  showDialog(
    // barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        content: SizedBox(
          child: (!kIsWeb)
              ? Image(
                  image: NetworkImage(
                      "https://adminpoin.ingsilver.co.id/images/uploads/users_profile/$_profilePicture"),
                  fit: BoxFit.contain,
                  key: ValueKey(new Random().nextInt(100)),
                )
              : Image.asset("assets/images/logo_apps.png"),
        ),
      );
    },
  );
}
