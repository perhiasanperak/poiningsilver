// import 'dart:html' as _html;
import 'package:flutter/material.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class AboutPage extends StatefulWidget {
  // const AboutPage({ Key? key }) : super(key: key);

  @override
  _AboutPageState createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  String _fbUrl = "https://www.facebook.com/pusatgrosirperhiasanperak925";
  String _igUrl = "https://www.instagram.com/pusatgrosirperhiasanperak1/";
  String _twtUrl = "https://twitter.com/perhiasan_perak";
  String _isUrl = "https://ingsilver.co.id/";
  String _waUrl =
      "https://api.whatsapp.com/send/?phone=6281380716125&text=Saya+memiliki+pertanyaan+mengenai+Aplikasi+IS+Point,+Apakah+bisa+dibantu%3F&app_absent=0";
  String? appName, packageName, appVersion, buildNumber;

  getPackageInfo() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();

    appName = packageInfo.appName;
    packageName = packageInfo.packageName;
    appVersion = packageInfo.version;
    buildNumber = packageInfo.buildNumber;
    print(
        "App Name : $appName \nPackage Name : $packageName \nVersion : $appVersion \nBuild Number : $buildNumber");
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getPackageInfo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Stack(
        children: [
          Container(
            child: Column(
              children: [
                Expanded(
                  flex: 12,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    child: Column(
                      children: [
                        Container(
                          height: 200,
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                child: Image.asset(
                                  "assets/images/logo_is.png",
                                  width: 150,
                                  fit: BoxFit.fitWidth,
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text("Version : $appVersion"),
                                  SizedBox(width: 2),
                                  // Text(
                                  //   "Beta",
                                  //   style: TextStyle(color: Colors.red[600]),
                                  // )
                                ],
                              )
                            ],
                          ),
                        ),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            // color: Colors.white,
                            border: Border(
                                bottom: BorderSide(color: Colors.grey[400]!)),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.blue[200]!,
                                blurRadius: 20,
                                spreadRadius: 1,
                                offset: Offset(0, 15),
                              )
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(
                            // height: ,
                            // color: Colors.blue,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Expanded(
                                  child: Container(
                                    padding: EdgeInsets.symmetric(
                                        vertical: 20, horizontal: 10),
                                    // height: 200,
                                    // color: Colors.white,
                                    child: SingleChildScrollView(
                                      child: Text(
                                        "IS Point is provide to the customers of PT. IS Ing Silver. Customers can view their transaction, point history, and do some change in their profile.",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 250,
                                  // color: Colors.green,
                                  child: Column(
                                    children: [
                                      ButtonAboutWidget(
                                          "facebook_color.png",
                                          "Follow Facebook",
                                          _fbUrl,
                                          Colors.blue),
                                      ButtonAboutWidget(
                                          "twitter_color.png",
                                          "Follow Twitter",
                                          _twtUrl,
                                          Colors.blue[200]),
                                      ButtonAboutWidget(
                                          "instagram_color.png",
                                          "Follow Instagram",
                                          _igUrl,
                                          Colors.red[300]),
                                      ButtonAboutWidget(
                                          "whatsapp_color.png",
                                          "Contact us by WA",
                                          _waUrl,
                                          Colors.green[300]),
                                      ButtonAboutWidget(
                                          "logo_is.png",
                                          "Visit our website",
                                          _isUrl,
                                          Colors.black54),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                    flex: 1,
                    child: Container(
                      // height: 45,
                      width: double.infinity,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "2021 PT. IS Ing Silver All Right Reserved",
                            style: TextStyle(color: Colors.white),
                          ),
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Developed",
                                ),
                                // WidgetSpan(
                                //   child: Icon(
                                //     Icons.favorite_sharp,
                                //     size: 14,
                                //     color: Colors.red,
                                //   ),
                                // ),
                                TextSpan(
                                  text: " By Kevin",
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.blue[200]!,
                              blurRadius: 20,
                              spreadRadius: 1,
                              offset: Offset(0, 6))
                        ],
                      ),
                    ))
              ],
            ),
          ),
        ],
      )),
    );
  }
}

class ButtonAboutWidget extends StatelessWidget {
  ButtonAboutWidget(this.itemIcon, this.itemName, this.itemUrl, this.itemColor);

  final String itemIcon;
  final String itemName;
  final String itemUrl;
  final Color? itemColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Material(
        color: itemColor,
        child: new Bounceable(
          onTap: () async {
            if (await canLaunch(itemUrl)) {
              await launch(itemUrl, forceSafariVC: false);
            } else {
              throw 'Could not launch $itemUrl';
            }
          },
          // splashColor: Colors.red,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            height: 50,
            width: double.infinity,
            // color: Colors.yellow,
            decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                    bottom: BorderSide(color: Colors.grey[200]!),
                    top: BorderSide(color: Colors.grey[200]!))),
            child: Row(
              children: [
                Container(
                    width: 30, child: Image.asset("assets/images/$itemIcon")),
                SizedBox(width: 10),
                Text(itemName),
                Spacer(),
                Icon(Icons.arrow_right)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
