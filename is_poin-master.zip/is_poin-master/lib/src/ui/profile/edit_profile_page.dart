import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as _http;
import 'package:flutter/material.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/widgets/custom_loading_button.dart';

class EditProfilePage extends StatefulWidget {
  String? idUser, name, email, phone, birthday;
  EditProfilePage(
      {required this.idUser,
      required this.name,
      required this.email,
      required this.phone,
      required this.birthday});
  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  ApiService apiService = ApiService();
  bool isLoading = false;
  final _key = new GlobalKey<FormState>();
  String? _name,
      _email,
      _phone,
      _birthday,
      _initName,
      _initEmail,
      _initPhone,
      _initBirthday;
  final dateBirthController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // getProfile();
    _initName = widget.name;
    _initEmail = widget.email;
    _initPhone = widget.phone;
    _initBirthday = widget.birthday;
    _birthday = _initBirthday;
    dateBirthController.text = _initBirthday!;
  }

  Future updateProfile() async {
    final response = await _http
        .post(Uri.parse("${apiService.apiUrl}updateProfile.php"), body: {
      "kode_cst": widget.idUser,
      "nama_cst": _name!.toUpperCase(),
      "email": _email,
      "telp": _phone,
      "birthday": _birthday
    });
    final data = jsonDecode(response.body);
    int? value = data['value'];
    String? pesan = data['message'];

    // _expPoin = data['exp_poin'];
    // _totalTrans = data['total_transaksi'];

    // print("Nama Customer $_name");
    if (value == 1) {
      // print(pesan);
      Navigator.of(context).pop();
      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("Success"),
                content: new Text(pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    // isDefaultAction: false,
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      setState(() {
        isLoading = false;
      });
    } else {
      // print(pesan);
      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("Error"),
                content: new Text(pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    // isDefaultAction: false,
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      setState(() {
        isLoading = false;
      });
    }
    setState(() {});
  }

  check() {
    final form = _key.currentState!;
    if (form.validate()) {
      form.save();
      updateProfile();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    _initName = widget.name;
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              color: Colors.grey[200],
              padding: EdgeInsets.only(top: 10, left: 10, right: 10),
              child: Container(
                height: double.infinity,
                width: double.infinity,
                decoration:
                    BoxDecoration(borderRadius: BorderRadius.circular(20)),
                child: Column(
                  children: [
                    Container(
                      height: 200,
                      width: double.infinity,
                      color: Colors.transparent,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              width: 150,
                              child: Image.asset("assets/images/logo_is.png")),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(30),
                              topRight: Radius.circular(30)),
                          border: Border.all(
                              width: 1,
                              color: Colors.grey[350]!,
                              style: BorderStyle.solid),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black45,
                                blurRadius: 10,
                                spreadRadius: 1,
                                offset: Offset(0, 6))
                          ],
                        ),
                        child: ListView(
                          shrinkWrap: true,
                          children: [
                            Form(
                              key: _key,
                              child: Column(
                                children: [
                                  Container(
                                    padding: EdgeInsets.symmetric(vertical: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Name",
                                          style: TextStyle(
                                              fontSize: 16, color: Colors.grey),
                                        ),
                                        SizedBox(height: 10),
                                        TextFormField(
                                          // ignore: missing_return
                                          validator: (e) {
                                            if (e!.isEmpty) {
                                              return "Please insert name";
                                            }
                                          },
                                          onSaved: (e) => _name = e,
                                          textInputAction: TextInputAction.next,
                                          autofocus: false,
                                          initialValue: _initName,
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.blue[200]!,
                                                  width: 2.0),
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            prefixIcon: Icon(
                                                Icons.person_outline_rounded),
                                            contentPadding: EdgeInsets.fromLTRB(
                                                20.0, 10.0, 20.0, 10.0),
                                            border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: EdgeInsets.symmetric(vertical: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Email",
                                          style: TextStyle(
                                              fontSize: 16, color: Colors.grey),
                                        ),
                                        SizedBox(height: 10),
                                        TextFormField(
                                          // ignore: missing_return
                                          validator: (e) {
                                            if (e!.isEmpty) {
                                              return "Please insert email";
                                            }
                                          },
                                          onSaved: (e) => _email = e,
                                          textInputAction: TextInputAction.next,
                                          autofocus: false,
                                          initialValue: _initEmail,
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.blue[200]!,
                                                  width: 2.0),
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            prefixIcon:
                                                Icon(Icons.email_outlined),
                                            contentPadding: EdgeInsets.fromLTRB(
                                                20.0, 10.0, 20.0, 10.0),
                                            border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: EdgeInsets.symmetric(vertical: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Phone",
                                          style: TextStyle(
                                              fontSize: 16, color: Colors.grey),
                                        ),
                                        SizedBox(height: 10),
                                        TextFormField(
                                          // ignore: missing_return
                                          validator: (e) {
                                            if (e!.isEmpty) {
                                              return "Please insert phone";
                                            }
                                          },
                                          onSaved: (e) => _phone = e,
                                          textInputAction: TextInputAction.next,
                                          autofocus: false,
                                          initialValue: _initPhone,
                                          keyboardType: TextInputType.number,
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.blue[200]!,
                                                  width: 2.0),
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            prefixIcon:
                                                Icon(Icons.phone_outlined),
                                            contentPadding: EdgeInsets.fromLTRB(
                                                20.0, 10.0, 20.0, 10.0),
                                            border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: EdgeInsets.symmetric(vertical: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Date of birth",
                                          style: TextStyle(
                                              fontSize: 16, color: Colors.grey),
                                        ),
                                        SizedBox(height: 10),
                                        TextFormField(
                                          // ignore: missing_return
                                          validator: (e) {
                                            if (e!.isEmpty) {
                                              return "Please insert date of birth";
                                            }
                                          },
                                          textInputAction: TextInputAction.next,
                                          controller: dateBirthController,
                                          decoration: InputDecoration(
                                            hintText: 'Date of birth',
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.blue[200]!,
                                                  width: 2.0),
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            prefixIcon:
                                                Icon(Icons.date_range_rounded),
                                            contentPadding: EdgeInsets.fromLTRB(
                                                20.0, 10.0, 20.0, 10.0),
                                            border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8)),
                                          ),
                                          onTap: () async {
                                            DateTime selectedDate =
                                                DateTime.now();
                                            FocusScope.of(context)
                                                .requestFocus(new FocusNode());
                                            final DateTime? picked =
                                                await showDatePicker(
                                                    context: context,
                                                    initialDate: selectedDate,
                                                    firstDate: DateTime(1900),
                                                    lastDate: DateTime(2100));
                                            dateBirthController.text =
                                                picked.toString().split(' ')[0];
                                            if (dateBirthController.text ==
                                                "null") {
                                              dateBirthController.text =
                                                  _initBirthday!;
                                              _birthday = dateBirthController
                                                  .text
                                                  .toString();
                                            } else {
                                              _birthday = dateBirthController
                                                  .text
                                                  .toString();
                                            }
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        EdgeInsets.symmetric(vertical: 16.0),
                                    child: Material(
                                      borderRadius: BorderRadius.circular(32.0),
                                      shadowColor: Colors.black,
                                      elevation: 5.0,
                                      // child: _loadingButton(),
                                      child: (isLoading == true)
                                          ? _loadingButton()
                                          : _saveButton(context),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  MaterialButton _saveButton(BuildContext context) {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: () {
        setState(() {
          isLoading = true;
        });
        check();
      },
      color: Colors.blue[200],
      child: Text('Save', style: TextStyle(color: Colors.white)),
    );
  }

  MaterialButton _loadingButton() {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: null,
      color: Colors.black,
      child: CustomLoadingButton(),
    );
  }
}
