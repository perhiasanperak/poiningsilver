import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as _http;
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/widgets/custom_loading_button.dart';

class ChangePasswordPage extends StatefulWidget {
  String? idUser;
  ChangePasswordPage(this.idUser);
  @override
  _ChangePasswordPageState createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  // const AboutPage({ Key? key }) : super(key: key);

  // final _oldPassword = TextEditingController();
  // final _newPassword = TextEditingController();
  // final _confirmPassword = TextEditingController();
  ApiService apiService = ApiService();
  bool isLoading = false;
  final _key = new GlobalKey<FormState>();
  String? _oldPassword;
  String? _newPassword;
  String? _confirmPassword;

  bool? _secureText = true;
  bool _secureTextNew = true;
  bool _secureTextConfirm = true;
  int _showPassword = 0;

  showHide(_secure, int _row) {
    // print("Secure before : $_secureText");
    setState(() {
      if (_row == 1) {
        _secureText = !_secure;
      } else if (_row == 2) {
        _secureTextNew = !_secure;
      } else if (_row == 3) {
        _secureTextConfirm = !_secure;
      }
      // print("Secure after : $_secureText");
    });
  }

  Future updatePassword() async {
    final response = await _http
        .post(Uri.parse("${apiService.apiUrl}changePassword.php"), body: {
      "kode_cst": widget.idUser,
      "oldPassword": _oldPassword,
      "newPassword": _newPassword,
      "confirmPassword": _confirmPassword
    });
    final data = jsonDecode(response.body);
    int? value = data['value'];
    String? pesan = data['message'];

    // print("Nama Customer $_name");
    if (value == 1) {
      // print(pesan);
      Navigator.of(context).pop();
      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("Success"),
                content: new Text(pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    // isDefaultAction: false,
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      setState(() {
        isLoading = false;
      });
    } else {
      // print(pesan);

      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("Error"),
                content: new Text(pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    // isDefaultAction: false,
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      setState(() {
        isLoading = false;
      });
    }
    setState(() {});
    // return _name;
  }

  check() {
    final form = _key.currentState!;
    if (form.validate()) {
      form.save();
      updatePassword();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              color: Colors.grey[200],
              padding: EdgeInsets.only(top: 10, left: 10, right: 10),
              child: Container(
                height: double.infinity,
                width: double.infinity,
                decoration:
                    BoxDecoration(borderRadius: BorderRadius.circular(20)),
                child: Column(
                  children: [
                    Container(
                      height: 200,
                      width: double.infinity,
                      color: Colors.transparent,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              width: 150,
                              child: Image.asset("assets/images/logo_is.png")),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(30),
                              topRight: Radius.circular(30)),
                          border: Border.all(
                              width: 1,
                              color: Colors.grey[350]!,
                              style: BorderStyle.solid),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black45,
                                blurRadius: 10,
                                spreadRadius: 1,
                                offset: Offset(0, 6))
                          ],
                        ),
                        child: ListView(
                          shrinkWrap: true,
                          children: [
                            Form(
                              key: _key,
                              child: Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Old Password',
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 16,
                                        )),
                                    SizedBox(height: 8),
                                    TextFormField(
                                      // ignore: missing_return
                                      validator: (e) {
                                        if (e!.isEmpty) {
                                          return "Please insert password";
                                        }
                                      },
                                      onSaved: (e) => _oldPassword = e,
                                      textInputAction: TextInputAction.next,
                                      autofocus: false,
                                      obscureText: _secureText!,
                                      decoration: InputDecoration(
                                        hintText: 'Fill with your old password',
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: Colors.blue[200]!,
                                              width: 2.0),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        prefixIcon:
                                            Icon(Icons.lock_open_rounded),
                                        contentPadding: EdgeInsets.fromLTRB(
                                            20.0, 10.0, 20.0, 10.0),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                      ),
                                    ),
                                    SizedBox(height: 15),
                                    Text('New Password',
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 16,
                                        )),
                                    SizedBox(height: 8),
                                    TextFormField(
                                      // ignore: missing_return
                                      validator: (e) {
                                        if (e!.isEmpty) {
                                          return "Please insert new password";
                                        }
                                      },
                                      onSaved: (e) => _newPassword = e,
                                      textInputAction: TextInputAction.next,
                                      autofocus: false,
                                      obscureText: _secureText!,
                                      decoration: InputDecoration(
                                        hintText: 'Fill with your new password',
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: Colors.blue[200]!,
                                              width: 2.0),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        prefixIcon:
                                            Icon(Icons.vpn_key_outlined),
                                        contentPadding: EdgeInsets.fromLTRB(
                                            20.0, 10.0, 20.0, 10.0),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                      ),
                                    ),
                                    SizedBox(height: 15),
                                    Text('Confirm Password',
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 16,
                                        )),
                                    SizedBox(height: 8),
                                    TextFormField(
                                      // ignore: missing_return
                                      validator: (e) {
                                        if (e!.isEmpty) {
                                          return "Please insert confirm password";
                                        }
                                      },
                                      onSaved: (e) => _confirmPassword = e,

                                      autofocus: false,
                                      obscureText: _secureText!,
                                      decoration: InputDecoration(
                                        hintText: 'New password confirmation',
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: Colors.blue[200]!,
                                              width: 2.0),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        prefixIcon:
                                            Icon(Icons.vpn_key_outlined),
                                        contentPadding: EdgeInsets.fromLTRB(
                                            20.0, 10.0, 20.0, 10.0),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: StatefulBuilder(builder:
                                              (BuildContext context,
                                                  StateSetter
                                                      setRememberState) {
                                            return Container(
                                              width: 10,
                                              child: CheckboxListTile(
                                                contentPadding:
                                                    EdgeInsets.all(0),
                                                title: Text("Show Password",
                                                    style: TextStyle(
                                                      fontSize: 14,
                                                      color: Colors.grey,
                                                    )),
                                                value: (_showPassword == 1)
                                                    ? true
                                                    : false,
                                                onChanged: (bool? newValue) {
                                                  setRememberState(() {
                                                    _secureText = newValue;

                                                    if (_secureText!) {
                                                      // print("true");
                                                      _showPassword = 1;
                                                      setState(() {
                                                        _secureText = false;
                                                      });
                                                    } else {
                                                      // print("false");
                                                      _showPassword = 0;
                                                      setState(() {
                                                        _secureText = true;
                                                      });
                                                    }
                                                  });
                                                },
                                                activeColor: Color(0xFF4f4f4f),
                                                controlAffinity:
                                                    ListTileControlAffinity
                                                        .leading,
                                              ),
                                            );
                                          }),
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 16.0),
                                      child: Material(
                                        borderRadius:
                                            BorderRadius.circular(32.0),
                                        shadowColor: Colors.black,
                                        elevation: 5.0,
                                        // child: _saveButton(context),
                                        child: (isLoading == true)
                                            ? _loadingButton()
                                            : _saveButton(context),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  MaterialButton _saveButton(BuildContext context) {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: () {
        setState(() {
          isLoading = true;
        });
        check();
      },
      color: Colors.blue[200],
      child: Text('Save', style: TextStyle(color: Colors.white)),
    );
  }

  MaterialButton _loadingButton() {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: null,
      color: Colors.black,
      child: CustomLoadingButton(),
    );
  }
}
