class ApiService {
  // String apiUrl = "";
  String apiUrl = "https://adminpoin.ingsilver.co.id/mobile/api_poin/";
  // String apiUrl = "https://adminpoin.ingsilver.co.id/mobile/api_poin_testing/";
  // String apiUrl = "http://192.168.1.52:8080/api_ispoin/";
}
