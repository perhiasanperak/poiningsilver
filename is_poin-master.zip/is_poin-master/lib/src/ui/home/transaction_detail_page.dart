import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as _http;
import 'package:is_poin/src/ui/api/api.dart';
import 'package:shimmer/shimmer.dart';

class TransactionDetailPage extends StatefulWidget {
  final String? no_nota;
  TransactionDetailPage({required this.no_nota});

  @override
  _TransactionDetailPageState createState() => _TransactionDetailPageState();
}

class _TransactionDetailPageState extends State<TransactionDetailPage> {
  ApiService apiService = ApiService();
  int? _idTrans;
  String? _noNota,
      _tanggal,
      _kodeCust,
      _namaCust,
      _totalPoin,
      _total = "-",
      _message,
      _dapatPoin = "-",
      _pakaiPoin = "-";
  var value;
  // var _detailTransaction = [];
  @override
  Future getDetailTransaction() async {
    final response = await _http.post(
        Uri.parse("${apiService.apiUrl}getDetailTrans.php"),
        body: {"no_nota": widget.no_nota});
    final data = jsonDecode(response.body);
    String? _pesan = data['message'];
    int? value = data['value'];
    // _detailTransaction = data['detail_transaction'];
    _idTrans = data['detail_transaction'][0]['id_trans'];
    _noNota = data['detail_transaction'][0]['no_nota'];
    _tanggal = data['detail_transaction'][0]['tanggal'];
    _kodeCust = data['detail_transaction'][0]['kode_cst'];
    _namaCust = data['detail_transaction'][0]['nama_cst'];
    _totalPoin = data['detail_transaction'][0]['total_poin'];
    _total = data['detail_transaction'][0]['total'];
    _dapatPoin = data['detail_transaction'][0]['dapat_poin'];
    _pakaiPoin = data['detail_transaction'][0]['pakai_poin'];
    _message = data['detail_transaction'][0]['keterangan'];
    if (value == 1) {
      print(_pesan);
      print("${data['detail_transaction'][0]['no_nota']}");
    } else {
      print(_pesan);
    }
    setState(() {});
  }

  void initState() {
    super.initState();
    // getPref();
    getDetailTransaction();
    // print("No Nota : ${widget.no_nota}");
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    // print("ID Trans : $_idTrans");
    return Scaffold(
      body: SafeArea(
          child: Stack(
        children: [
          Container(
            padding:
                EdgeInsets.only(top: (!kIsWeb) ? 10 : 0, left: 10, right: 10),
            color: Colors.grey[200],
            child: Container(
              height: double.infinity,
              width: double.infinity,
              decoration:
                  BoxDecoration(borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  Container(
                    height: 200,
                    margin: EdgeInsets.only(bottom: 20),
                    width: double.infinity,
                    color: Colors.grey[200],
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          "assets/images/logo_is.png",
                          width: 110,
                          fit: BoxFit.fitWidth,
                        ),
                        (_tanggal != null)
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 25,
                                    child: new Image.asset(
                                        "assets/images/check_3.gif"),
                                  ),
                                  SizedBox(width: 4),
                                  Text("Berhasil"),
                                ],
                              )
                            : Shimmer.fromColors(
                                baseColor: Colors.white,
                                highlightColor: Colors.grey[200]!,
                                child: Container(
                                  width: 100,
                                  height: 18,
                                  color: Colors.white,
                                  // color: Colors.red,
                                ),
                              ),
                        SizedBox(
                          height: 5,
                        ),
                        (_tanggal != null)
                            ? Text("${_tanggal}")
                            : Shimmer.fromColors(
                                baseColor: Colors.white,
                                highlightColor: Colors.grey[200]!,
                                child: Container(
                                  width: 120,
                                  height: 18,
                                  color: Colors.white,
                                  // color: Colors.red,
                                ),
                              ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30)),
                      border: Border.all(
                          width: 1,
                          color: Colors.grey[350]!,
                          style: BorderStyle.solid),
                      // border: Border(
                      //     top: BorderSide(color: Colors.grey[200], width: 1)),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black45,
                            blurRadius: 10,
                            spreadRadius: 1,
                            offset: Offset(0, 6))
                      ],
                    ),
                    child: Row(
                      children: [
                        // Icon(
                        //   Icons.person,
                        //   size: 60,
                        // ),
                        Container(
                          width: 60,
                          child: Image.asset(
                            "assets/images/person_circle.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        Flexible(
                          child: (_namaCust != null)
                              ? Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      // "KEVIN LAURENCE HARTONO HARTONO HARTONO HARTONO",
                                      "${_namaCust!.toUpperCase()}",
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                    Text(
                                      "Customer Code : $_kodeCust",
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      "$_totalPoin Pts",
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ],
                                )
                              : Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Shimmer.fromColors(
                                      baseColor: Colors.grey[200]!,
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width: 200,
                                        height: 18,
                                        color: Colors.grey[200],
                                        // color: Colors.red,
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Shimmer.fromColors(
                                      baseColor: Colors.grey[200]!,
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width: 150,
                                        height: 10,
                                        color: Colors.grey[200],
                                        // color: Colors.red,
                                      ),
                                    ),
                                    SizedBox(height: 3),
                                    Shimmer.fromColors(
                                      baseColor: Colors.grey[200]!,
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width: 120,
                                        height: 10,
                                        color: Colors.grey[200],
                                        // color: Colors.red,
                                      ),
                                    )
                                  ],
                                ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 200,
                      width: double.infinity,
                      padding:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border(
                              top: BorderSide(color: Colors.grey[200]!))),
                      child: (_noNota != null)
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Transaction Detail",
                                  style: TextStyle(
                                    fontSize: 22,
                                    color: Colors.blue[200],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 15),
                                DetailItemTransaction(
                                    titleItem: "Invoice",
                                    itemDetail: _noNota,
                                    itemColor: Colors.black),
                                DetailItemTransaction(
                                    titleItem: "Message",
                                    itemDetail: _message,
                                    itemColor: Colors.black),
                                DetailItemTransaction(
                                    titleItem: "Redeem",
                                    itemDetail: "-$_pakaiPoin Pts",
                                    itemColor: Colors.red[700]),
                                DetailItemTransaction(
                                    titleItem: "Reward",
                                    itemDetail: "+$_dapatPoin Pts",
                                    itemColor: Colors.green[700]),
                                DetailItemTransaction(
                                    titleItem: "Total",
                                    itemDetail: "Rp $_total",
                                    itemColor: Colors.black),
                              ],
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Shimmer.fromColors(
                                  baseColor: Colors.grey[200]!,
                                  highlightColor: Colors.white,
                                  child: Container(
                                    width: 200,
                                    height: 22,
                                    color: Colors.grey[200],
                                    // color: Colors.red,
                                  ),
                                ),
                                SizedBox(height: 15),
                                Expanded(
                                  child: ListView.builder(
                                      itemCount: 5,
                                      itemBuilder: (context, i) =>
                                          TrxItemDetail()),
                                ),
                              ],
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      )),
    );
  }
}

class TrxItemDetail extends StatelessWidget {
  const TrxItemDetail({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 32),
      child: Row(
        children: [
          Shimmer.fromColors(
            baseColor: Colors.grey[200]!,
            highlightColor: Colors.white,
            child: Container(
              width: 150,
              height: 20,
              color: Colors.grey[200],
            ),
          ),
          Spacer(),
          Shimmer.fromColors(
            baseColor: Colors.grey[200]!,
            highlightColor: Colors.white,
            child: Container(
              width: 120,
              height: 20,
              color: Colors.grey[200],
            ),
          ),
        ],
      ),
    );
  }
}

class DetailItemTransaction extends StatelessWidget {
  final String? itemDetail, titleItem;
  final Color? itemColor;
  DetailItemTransaction(
      {required this.titleItem,
      required this.itemDetail,
      required this.itemColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 30),
      child: Row(
        children: [
          Text(
            (titleItem == null) ? "NULL" : titleItem!,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Spacer(),
          Text((itemDetail == null) ? "-" : itemDetail!,
              style: TextStyle(fontSize: 18, color: itemColor)),
        ],
      ),
    );
  }
}
