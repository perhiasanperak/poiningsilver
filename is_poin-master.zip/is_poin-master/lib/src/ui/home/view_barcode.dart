import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_barcodes/barcodes.dart';

modalDetail(BuildContext context, String? custCode) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          // title: Text('Please choose media to select'),
          content: Container(
            height: MediaQuery.of(context).size.height / 3,
            child: Column(
              children: <Widget>[
                Flexible(
                  child: SfBarcodeGenerator(
                    barColor: Colors.black,
                    // textStyle: TextStyle(color: Colors.black),
                    value: '$custCode',
                    symbology: QRCode(),
                    // showValue: true,
                  ),
                ),
              ],
            ),
          ),
        );
      });
}
