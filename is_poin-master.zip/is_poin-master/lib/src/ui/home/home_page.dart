import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:animated_background/animated_background.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:http/http.dart' as _http;
import 'package:flutter/material.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/ui/home/transaction_detail_page.dart';
import 'package:is_poin/src/ui/home/view_all_transaction_page.dart';
import 'package:is_poin/src/utils/custom_colors.dart';

import 'package:is_poin/src/widgets/list_shimmer_widget.dart';
import 'package:is_poin/src/widgets/list_transaction_widget.dart';
import 'package:is_poin/src/widgets/point_card_widget.dart';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  final String? id;
  HomePage({required this.id});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  ApiService apiService = ApiService();
  CustomColors _customColor = CustomColors();
  String? _id, _idIPos, _rpPoin, _name, _expPoin, noNota;
  List<dynamic>? _transHome = [];
  bool _loadShimmer = true;
  int? _expCount;

  ParticleOptions particleOptions = ParticleOptions(
    baseColor: Colors.blue,
    spawnOpacity: 0.0,
    opacityChangeRate: 0.25,
    minOpacity: 0.1,
    maxOpacity: 0.4,
    spawnMinSpeed: 30.0,
    spawnMaxSpeed: 70.0,
    spawnMinRadius: 7.0,
    spawnMaxRadius: 15.0,
    particleCount: 40,
  );

  getPref() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      _idIPos = preferences.getString("idIpos");
      _name = preferences.getString("nama_home");
      _expPoin = preferences.getString("expPoinRaw");
      _rpPoin = preferences.getString("rpPoin");
      // print("Dark Mode (Home): ${preferences.getBool('dark_mode')}");
    });
  }

  savePref(String? nama, String? rpPoin, String? expPoin, int? expCount) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      preferences.setString("nama_home", nama!);
      preferences.setString("rpPoin", rpPoin!);
      preferences.setString("expPoinRaw", expPoin!);
      preferences.setInt("expCount", expCount!);

      preferences.commit();
    });
  }

  // ? Call Api
  Future getHome() async {
    final response = await _http.post(
        Uri.parse("${apiService.apiUrl}getHome.php"),
        body: {"kode_cst": _id});
    final data = jsonDecode(response.body);

    int? value = data['value'];
    String? pesan = data['message'];
    _name = data['nama_cst'];
    _idIPos = data['id_ipos'];
    _rpPoin = data['rp_poin'];
    _expPoin = data['exp_poin'];
    _transHome = data["trans_home"];
    _expCount = data['selisih_exp'];
    // print(_expCount);
    if (value == 1) {
      // print(data);
      // print(pesan);
      savePref(_name, _rpPoin, _expPoin, _expCount);
      // print(_transHome);
      _loadShimmer = false;
    } else {
      print(pesan);
    }
    setState(() {});
    // return _name;
  }

  @override
  void initState() {
    super.initState();
    getPref();
    _id = widget.id;
    getHome();
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          // color: Colors.blue[200],
          decoration: BoxDecoration(
              // color: Colors.grey[200],
              // gradient: LinearGradient(
              //   colors: [
              //     // const Color(0xFF94B6FF),
              //     // const Color(0xFF00CCFF),
              //     _customColor.gradColor,
              //     _customColor.themeColor,
              //   ],
              //   begin: const FractionalOffset(0.0, 1.0),
              //   end: const FractionalOffset(1.0, 0.0),
              //   stops: [0.0, 1.0],
              //   tileMode: TileMode.clamp,
              // ),
              ),
        ),
        // AnimatedBackground(
        //   behaviour: RandomParticleBehaviour(options: particleOptions),
        //   // behaviour: BubblesBehaviour(),
        //   vsync: this,
        //   child: Container(),
        // ),
        LiquidPullToRefresh(
          color: Colors.transparent,
          // backgroundColor: Colors.blue[200],
          backgroundColor: _customColor.gradColor,
          springAnimationDurationInMilliseconds: 500,
          showChildOpacityTransition: false,
          onRefresh: () async {
            setState(() {
              _loadShimmer = true;
            });
            getHome();
          },
          child: Container(
            child: CustomScrollView(
              physics: BouncingScrollPhysics(),
              slivers: [
                SliverList(
                    delegate: SliverChildListDelegate([
                  PointCardWIdget(
                    id: _id,
                    rpPoin: _rpPoin,
                    name: _name,
                    expPoin: _expPoin,
                    gradColor: _customColor.gradColor,
                    themeColor: _customColor.themeColor,
                  ),
                  SizedBox(height: 10),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text(
                          "Last Transaction",
                          style: TextStyle(
                            color: _customColor.textColorHighlight,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                        Spacer(),
                        TextButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => ViewAllTransactionPage(
                                        custCode: _id,
                                      )));
                            },
                            child: Text("View All"))
                      ],
                    ),
                  ),
                  Container(
                      width: double.infinity,
                      height: MediaQuery.of(context).size.height / 2.12,
                      padding: EdgeInsets.fromLTRB(10, 0, 10, 10),
                      child: (_loadShimmer == true)
                          ? ListShimmerWidget()
                          : (_transHome!.isEmpty)
                              ? Container(
                                  child: Center(
                                    child: Text(
                                        "You don't have any transactions yet."),
                                  ),
                                )
                              : ListView.builder(
                                  physics: BouncingScrollPhysics(),
                                  itemExtent: 80,
                                  itemCount: _transHome!.length,
                                  itemBuilder: (context, i) => Bounceable(
                                    onTap: () {
                                      if (_transHome![i]["no_nota"] ==
                                          "expired") {
                                      } else {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    TransactionDetailPage(
                                                        no_nota: _transHome![i]
                                                            ["no_nota"])));
                                      }
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(bottom: 10),
                                      child: ListTransactionWidget(
                                        noNota: "${_transHome![i]["no_nota"]}",
                                        tanggal: "${_transHome![i]["tanggal"]}",
                                        totalTrans: "${_transHome![i]["total"]}",
                                      ),
                                      decoration: BoxDecoration(
                                        // color: Colors.white54,
                                        color: _customColor.listItemCard,
                                        borderRadius: BorderRadius.circular(15),
                                        // boxShadow: [
                                        //   BoxShadow(
                                        //       color: Colors.grey[50],
                                        //       blurRadius: 1,
                                        //       spreadRadius: 1,
                                        //       offset: Offset(0, 1))
                                        // ],
                                      ),
                                    ),
                                  ),
                                )),
                ])),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
