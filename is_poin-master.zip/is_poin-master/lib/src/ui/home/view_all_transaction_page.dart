// import 'package:animated_floatactionbuttons/animated_floatactionbuttons.dart';
import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:incrementally_loading_listview/incrementally_loading_listview.dart';
import 'package:intl/intl.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/ui/home/transaction_detail_page.dart';
import 'package:is_poin/src/utils/custom_colors.dart';
import 'package:is_poin/src/widgets/custom_loading_indicator.dart';

import 'package:is_poin/src/widgets/list_shimmer_widget.dart';
import 'package:is_poin/src/widgets/list_transaction_widget.dart';
import 'package:line_icons/line_icons.dart';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as _http;

class ViewAllTransactionPage extends StatefulWidget {
  // const ViewAllTransaction({ Key? key }) : super(key: key);
  final String? custCode;
  ViewAllTransactionPage({required this.custCode});
  @override
  _ViewAllTransactionPageState createState() => _ViewAllTransactionPageState();
}

class _ViewAllTransactionPageState extends State<ViewAllTransactionPage> {
  ApiService apiService = ApiService();
  final _key = new GlobalKey<FormState>();
  String? _telp,
      _id,
      _dateFrom = "",
      _dateTo = "",
      _selectedRadio,
      noNota,
      filter = "tanggal",
      _sortType = "DESC";
  var valueResponse;
  List<dynamic>? _listTransaction = [];
  final dateFromController = TextEditingController();
  final dateToController = TextEditingController();
  int? _groupvalue = 0, priceValue = 0, invoiceValue;
  int? _currentMax = 15,
      offset = 0,
      totalItem = 0,
      itemPerPage = 0,
      itemPerPageTemp = 0;
  List? _listInvoice, _listDate, _listTotal;
  bool _loadMore = true, _loadShimmer = true;
  CustomColors _customColor = CustomColors();

  ScrollController _scrollController = ScrollController();

  DateFormat dateFormat = DateFormat('dd-MM-yyyy');

  getTransaction() async {
    print("ID VIEW: ${widget.custCode}");
    print("Load shimmer status : $_loadShimmer");
    if (_listInvoice != null) {
      _currentMax = 15;
      offset = 0;
      totalItem = 0;
      itemPerPage = 0;
      itemPerPageTemp = 0;
      _listInvoice!.clear();
      _listDate!.clear();
      _listTotal!.clear();
      // _listPoint.clear();
    }
    print(filter);
    final response = await _http
        .post(Uri.parse("${apiService.apiUrl}getAllTrans.php"), body: {
      "kode_cst": widget.custCode,
      "filter": filter,
      "sortType": _sortType,
      "fromDate": _dateFrom,
      "toDate": _dateTo,
      "offset": offset.toString()
    });
    final data = jsonDecode(response.body);
    String? _pesan = data['message'];
    int? valueResponse = data['value'];

    itemPerPage = data['total_item'];
    totalItem = itemPerPage;
    _listTransaction = data['list_transaction'];
    // noNota = _listTransaction[0]["no_nota"];
    if (valueResponse == 1) {
      print(_pesan);
      // print(_listTransaction);
      _listInvoice =
          List.generate(itemPerPage!, (i) => _listTransaction![i]["no_nota"]);
      // _listInvoice = List.generate(10, (i) => i.toString());
      _listDate =
          List.generate(itemPerPage!, (i) => _listTransaction![i]["tanggal"]);
      _listTotal =
          List.generate(itemPerPage!, (i) => _listTransaction![i]["total"]);
      if (itemPerPage! < 10) {
        _loadMore = false;
      }
      print("Item per page: $itemPerPage");
      _loadShimmer = false;
      print("Load shimmer status : $_loadShimmer");
    } else {
      print(_pesan);
      _loadShimmer = false;
    }
    setState(() {});
  }

  _getMoreData() async {
    print("Load more data");
    offset = _currentMax;
    final response = await _http
        .post(Uri.parse("${apiService.apiUrl}getAllTrans.php"), body: {
      "kode_cst": widget.custCode,
      "filter": filter,
      "sortType": _sortType,
      "fromDate": _dateFrom,
      "toDate": _dateTo,
      "offset": offset.toString()
    });
    final data = jsonDecode(response.body);
    String? _pesan = data['message'];
    int? valueResponse = data['value'];
    itemPerPage = data['total_item'];

    // print("Item Per Page : $itemPerPage");
    _listTransaction = data['list_transaction'];

    if (valueResponse == 1) {
      // print(_pesan);
      // print(_listTransaction);
      // if (itemPerPage < 10) {
      //   // totalItem = totalItem + data['total_item'];
      //   totalItem = totalItem + itemPerPage;
      // } else {
      //   totalItem = totalItem + itemPerPage;
      // }
      totalItem = totalItem! + itemPerPage!;
      // print("Total item : $totalItem");
      if (_listTransaction![0]["no_nota"] != null) {
        int j = 0;
        for (int i = _currentMax!; i < _currentMax! + itemPerPage!; i++) {
          // _listInvoice.add(i.toString());
          _listInvoice!.add(_listTransaction![j]["no_nota"]);
          _listDate!.add(_listTransaction![j]["tanggal"]);
          _listTotal!.add(_listTransaction![j]["total"]);
          j++;
        }
      } else {}
      _loadShimmer = false;
    } else {
      print(_pesan);

      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("No Item"),
                content: new Text(_pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      // setState(() {
      _loadMore = false;
      // print("Load status : $_loadMore");
      // });
    }
    _currentMax = _currentMax! + 15;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    // getPref();
    getTransaction();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        _getMoreData();
      }
    });
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget floatMenu1() {
      return Container(
        child: FloatingActionButton(
            backgroundColor: Colors.blue[200],
            heroTag: "Sort",
            onPressed: () {
              sortModal(context);
            },
            tooltip: 'Sort by total',
            child: Icon(Icons.attach_money_outlined)),
      );
    }

    Widget floatMenu2() {
      return Container(
        child: FloatingActionButton(
          backgroundColor: Colors.blue[200],
          heroTag: "Dates",
          onPressed: () {
            sortDateModal(context);
          },
          tooltip: 'Sort by date',
          child: Icon(Icons.date_range_outlined),
        ),
      );
    }

    Widget floatMenu3() {
      return Container(
        child: FloatingActionButton(
          backgroundColor: Colors.blue[200],
          heroTag: "DatesRange",
          onPressed: () {
            datesModal(context);
          },
          tooltip: 'Filter by date range',
          child: Icon(Icons.filter_alt_outlined),
        ),
      );
    }

    return Scaffold(
        body: Stack(
          children: [
            Container(
                // width: double.infinity,
                height: MediaQuery.of(context).size.height,
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
                decoration: BoxDecoration(
                  color: _customColor.backgroundColor,
                  // borderRadius: BorderRadius.circular(20),
                  // boxShadow: [
                  //   BoxShadow(
                  //       color: Colors.grey[200],
                  //       blurRadius: 10,
                  //       spreadRadius: 1,
                  //       offset: Offset(0, 4))
                  // ],
                  // gradient: LinearGradient(
                  //   colors: [
                  //     // const Color(0xFF94B6FF),
                  //     // const Color(0xFF00CCFF),
                  //     _customColor.themeColor,
                  //     _customColor.gradColor,
                  //   ],
                  //   begin: const FractionalOffset(0.0, 1.0),
                  //   end: const FractionalOffset(1.0, 0.0),
                  //   stops: [0.0, 1.0],
                  //   tileMode: TileMode.clamp,
                  // ),
                ),
                // child: (noNota == null || _loadShimmer == true)
                child: LiquidPullToRefresh(
                    color: Colors.transparent,
                    backgroundColor: _customColor.gradColor,
                    // animSpeedFactor: 1.0,
                    springAnimationDurationInMilliseconds: 500,
                    showChildOpacityTransition: false,
                    onRefresh: () async {
                      // ! reset filter
                      setState(() {
                        _loadShimmer = true;
                        filter = "tanggal";
                        _sortType = "DESC";
                      });
                      getTransaction();
                    },
                    child: SingleChildScrollView(
                        physics: BouncingScrollPhysics(),
                        child: Container(
                          // color: Colors.red,
                          height: MediaQuery.of(context).size.height,
                          child: (_loadShimmer == true)
                              ? ListShimmerWidget()
                              : (totalItem == null)
                                  ? Container(
                                      child: Center(
                                        child: Text(
                                            "You don't have any transactions yet."),
                                      ),
                                    )
                                  : ListView.builder(
                                      physics: BouncingScrollPhysics(),
                                      itemExtent: 80,
                                      controller: _scrollController,
                                      itemCount: totalItem! + 1,
                                      itemBuilder: (context, i) {
                                        if (i == _listInvoice!.length) {
                                          if (_loadMore == true) {
                                            // print("LOAD!");
                                            // print("Load status : $_loadMore");
                                            // return CupertinoActivityIndicator();
                                            return CustomLoadingIndicator();
                                          } else {
                                            // print("NO LOAD!");
                                            // return CupertinoActivityIndicator();
                                            // print("Load status : $_loadMore");
                                            return Container();
                                          }
                                        }
                                        return Bounceable(
                                          onTap: () {
                                            if (_listInvoice![i] != "expired") {
                                              Navigator.of(context).push(
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                          TransactionDetailPage(
                                                            no_nota:
                                                                _listInvoice![
                                                                    i],
                                                          )));
                                            }
                                          },
                                          child: Container(
                                            margin: EdgeInsets.only(bottom: 10),
                                            child: ListTransactionWidget(
                                                noNota: _listInvoice![i],
                                                tanggal: _listDate![i],
                                                totalTrans: _listTotal![i]),
                                            decoration: BoxDecoration(
                                              // color: Colors.white,
                                              color: _customColor.listItemCard,
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              // boxShadow: [
                                              //   BoxShadow(
                                              //       color: Colors.grey[50],
                                              //       blurRadius: 1,
                                              //       spreadRadius: 1,
                                              //       offset: Offset(0, 1))
                                              // ],
                                            ),
                                          ),
                                        );
                                      }),
                        )))),
          ],
        ),
        floatingActionButton: FabCircularMenu(
            fabColor: Color(0xFF94B6FF),
            ringColor: Colors.blue[200],
            ringDiameter: 200,
            fabCloseIcon: Icon(
              LineIcons.times,
              color: Colors.white,
            ),
            fabOpenIcon: Icon(LineIcons.bars, color: Colors.white),
            // ringWidth: 30,
            children: <Widget>[
              Tooltip(
                message: 'Sort by total',
                padding: EdgeInsets.all(15),
                margin: EdgeInsets.all(15),
                showDuration: Duration(seconds: 5),
                decoration: BoxDecoration(
                  color: Color(0xFF94B6FF).withOpacity(0.8),
                  borderRadius: const BorderRadius.all(Radius.circular(4)),
                ),
                textStyle: TextStyle(color: Colors.white),
                preferBelow: false,
                verticalOffset: 10,
                child: IconButton(
                    icon: Icon(LineIcons.dollarSign, color: Colors.white),
                    onPressed: () {
                      sortModal(context);
                    }),
              ),
              Tooltip(
                message: 'Sort by dates',
                padding: EdgeInsets.all(15),
                margin: EdgeInsets.all(15),
                showDuration: Duration(seconds: 5),
                decoration: BoxDecoration(
                  color: Color(0xFF94B6FF).withOpacity(0.8),
                  borderRadius: const BorderRadius.all(Radius.circular(4)),
                ),
                textStyle: TextStyle(color: Colors.white),
                preferBelow: false,
                verticalOffset: 10,
                child: IconButton(
                    icon: Icon(LineIcons.sort, color: Colors.white),
                    onPressed: () {
                      sortDateModal(context);
                    }),
              ),
              Tooltip(
                message: 'Filter by date range',
                padding: EdgeInsets.all(15),
                margin: EdgeInsets.all(15),
                showDuration: Duration(seconds: 5),
                decoration: BoxDecoration(
                  color: Color(0xFF94B6FF).withOpacity(0.8),
                  borderRadius: const BorderRadius.all(Radius.circular(4)),
                ),
                textStyle: TextStyle(color: Colors.white),
                preferBelow: false,
                verticalOffset: 10,
                child: IconButton(
                    icon: Icon(LineIcons.calendar, color: Colors.white),
                    onPressed: () {
                      datesModal(context);
                    }),
              )
            ])
        // floatingActionButton: AnimatedFloatingActionButton(
        //     //Fab list
        //     fabButtons: <Widget>[floatMenu3(), floatMenu2(), floatMenu1()],
        //     // colorStartAnimation: Colors.blue[200],
        //     // colorEndAnimation: Colors.red[400],
        //     colorStartAnimation: _customColor.themeColor,
        //     colorEndAnimation: _customColor.gradColor,
        //     animatedIconData: AnimatedIcons.menu_close //To principal button
        //     ),
        // floatingActionButton: FabCircularMenu(
        //     fabColor: Colors.indigo,
        //     ringColor: Colors.black54,
        //     ringDiameter: 200,
        //     fabCloseIcon: Icon(
        //       LineIcons.times,
        //       color: Colors.white,
        //     ),
        //     fabOpenIcon: Icon(LineIcons.bars, color: Colors.white70),
        //     // ringWidth: 30,
        //     children: <Widget>[
        //       IconButton(
        //           icon: Icon(LineIcons.sort, color: Colors.white70),
        //           tooltip: "Sort by total",
        //           onPressed: () {
        //             sortModal(context);
        //             print('Home');
        //           }),
        //       IconButton(
        //           icon: Icon(LineIcons.calendar, color: Colors.white70),
        //           tooltip: "Sort by dates",
        //           onPressed: () {
        //             sortDateModal(context);
        //             print('Favorite');
        //           }),
        //       IconButton(
        //           icon: Icon(LineIcons.dollarSign, color: Colors.white70),
        //           tooltip: "Filter by date range",
        //           onPressed: () {
        //             datesModal(context);
        //             print('Favorite');
        //           })
        //     ])
        );
  }

  Future<void> sortModal(BuildContext context) {
    return showModalBottomSheet<void>(
        backgroundColor: Colors.transparent,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter setModalState) {
            return Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height / 2.5,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(25),
                      topRight: Radius.circular(25)),
                ),
                child: Form(
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    child: Column(
                      children: [
                        Text("Sort by Total", style: TextStyle(fontSize: 20)),
                        SizedBox(height: 20),
                        Container(
                          decoration: BoxDecoration(
                              color: _selectedRadio == "largest"
                                  ? Colors.blue[200]
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(20)),
                          child: RadioListTile(
                            value: "largest",
                            title: Text("Largest to Smallest",
                                style: TextStyle(
                                    color: _selectedRadio == "largest"
                                        ? Colors.white
                                        : Colors.black)),
                            groupValue: _selectedRadio,
                            activeColor: Colors.blue,
                            subtitle: Text("Select one",
                                style: TextStyle(
                                    color: _selectedRadio == "largest"
                                        ? Colors.white30
                                        : Colors.grey[400])),
                            onChanged: (String? value) {
                              setModalState(() {
                                _selectedRadio = value;
                                print(_selectedRadio);
                              });
                            },
                          ),
                        ),
                        SizedBox(height: 5),
                        Container(
                          decoration: BoxDecoration(
                              color: _selectedRadio == "smallest"
                                  ? Colors.blue[200]
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(20)),
                          child: RadioListTile(
                            value: "smallest",
                            title: Text("Smallest to Largest",
                                style: TextStyle(
                                    color: _selectedRadio == "smallest"
                                        ? Colors.white
                                        : Colors.black)),
                            groupValue: _selectedRadio,
                            activeColor: Colors.blue,
                            subtitle: Text("Select one",
                                style: TextStyle(
                                    color: _selectedRadio == "smallest"
                                        ? Colors.white30
                                        : Colors.grey[400])),
                            onChanged: (String? value) {
                              setModalState(() {
                                _selectedRadio = value;
                                print(_selectedRadio);
                              });
                            },
                          ),
                        ),
                        Flexible(
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 16.0),
                            child: Material(
                              borderRadius: BorderRadius.circular(32.0),
                              shadowColor: Colors.black,
                              elevation: 5.0,
                              // child: (state is AuthLoading)
                              //     ? _loadingButton()
                              //     : _resetButton(context),
                              child: _submitButton(
                                  context, _selectedRadio, "", ""),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ));
          });
        });
  }

  Future<void> sortDateModal(BuildContext context) {
    return showModalBottomSheet<void>(
        backgroundColor: Colors.transparent,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter setModalState) {
            return Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height / 2.5,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(25),
                      topRight: Radius.circular(25)),
                ),
                child: Form(
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    child: Column(
                      children: [
                        Text("Sort by Date", style: TextStyle(fontSize: 20)),
                        SizedBox(height: 20),
                        Container(
                          decoration: BoxDecoration(
                              color: _selectedRadio == "newest"
                                  ? Colors.blue[200]
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(20)),
                          child: RadioListTile(
                            value: "newest",
                            title: Text("Newest to Oldest",
                                style: TextStyle(
                                    color: _selectedRadio == "newest"
                                        ? Colors.white
                                        : Colors.black)),
                            groupValue: _selectedRadio,
                            activeColor: Colors.blue,
                            subtitle: Text("Select one",
                                style: TextStyle(
                                    color: _selectedRadio == "newest"
                                        ? Colors.white30
                                        : Colors.grey[400])),
                            onChanged: (String? value) {
                              setModalState(() {
                                _selectedRadio = value;
                                print(_selectedRadio);
                              });
                            },
                          ),
                        ),
                        SizedBox(height: 5),
                        Container(
                          decoration: BoxDecoration(
                              color: _selectedRadio == "oldest"
                                  ? Colors.blue[200]
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(20)),
                          child: RadioListTile(
                            value: "oldest",
                            title: Text("Oldest to Newest",
                                style: TextStyle(
                                    color: _selectedRadio == "oldest"
                                        ? Colors.white
                                        : Colors.black)),
                            groupValue: _selectedRadio,
                            activeColor: Colors.blue,
                            subtitle: Text("Select one",
                                style: TextStyle(
                                    color: _selectedRadio == "oldest"
                                        ? Colors.white30
                                        : Colors.grey[400])),
                            onChanged: (String? value) {
                              setModalState(() {
                                _selectedRadio = value;
                                print(_selectedRadio);
                              });
                            },
                          ),
                        ),
                        Flexible(
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 16.0),
                            child: Material(
                              borderRadius: BorderRadius.circular(32.0),
                              shadowColor: Colors.black,
                              elevation: 5.0,
                              // child: (state is AuthLoading)
                              //     ? _loadingButton()
                              //     : _resetButton(context),
                              child: _submitButton(
                                  context, _selectedRadio, "", ""),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ));
          });
        });
  }

  Future<void> datesModal(BuildContext context) {
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('dd-MM-yyyy').format(now);
    print(formattedDate);
    return showModalBottomSheet<void>(
        backgroundColor: Colors.transparent,
        context: context,
        builder: (BuildContext context) {
          return Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height / 4,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(25),
                    topRight: Radius.circular(25)),
              ),
              child: Form(
                key: _key,
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  child: Column(
                    children: [
                      Text("Select Date Range", style: TextStyle(fontSize: 20)),
                      SizedBox(height: 20),
                      Row(
                        children: [
                          Container(
                            // color: Colors.green,
                            width: 150,
                            child: TextFormField(
                              validator: (e) {
                                if (e!.isEmpty) {
                                  return "Please insert 'from date'";
                                }
                              },
                              controller: dateFromController,
                              textAlign: TextAlign.center,
                              decoration: InputDecoration(
                                hintText: 'From',
                                contentPadding:
                                    EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15.0)),
                              ),
                              onTap: () async {
                                DateTime selectedDate = DateTime.now();
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());
                                final DateTime? picked = await showDatePicker(
                                    context: context,
                                    initialDate: selectedDate,
                                    firstDate: DateTime(1900),
                                    lastDate: DateTime(2100));
                                dateFromController.text =
                                    picked.toString().split(' ')[0];
                                if (dateFromController.text == "null") {
                                  dateFromController.text = '';
                                  _dateFrom =
                                      dateFromController.text.toString();
                                } else {
                                  _dateFrom =
                                      dateFromController.text.toString();
                                }
                                // _dateFrom = dateFromController.text.toString();
                                // _dateFrom = DateFormat('dd-MM-yyyy').format(selectedDate);
                              },
                            ),
                          ),
                          Spacer(),
                          Container(
                            // color: Colors.red,
                            width: 150,
                            child: TextFormField(
                              validator: (e) {
                                if (e!.isEmpty) {
                                  return "Please insert 'to date'";
                                }
                              },
                              textAlign: TextAlign.center,
                              controller: dateToController,
                              decoration: InputDecoration(
                                hintText: 'To',
                                contentPadding:
                                    EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15.0)),
                              ),
                              onTap: () async {
                                DateTime selectedDate = DateTime.now();
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());
                                final DateTime? picked = await showDatePicker(
                                    context: context,
                                    initialDate: selectedDate,
                                    firstDate: DateTime(1900),
                                    lastDate: DateTime(2100));
                                dateToController.text =
                                    picked.toString().split(' ')[0];
                                if (dateToController.text == "null") {
                                  dateToController.text = '';
                                  _dateTo = dateToController.text.toString();
                                } else {
                                  _dateTo = dateToController.text.toString();
                                }
                                // _dateTo = dateToController.text.toString();
                              },
                            ),
                          )
                        ],
                      ),
                      Flexible(
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 16.0),
                          child: Material(
                            borderRadius: BorderRadius.circular(32.0),
                            shadowColor: Colors.black,
                            elevation: 5.0,
                            // child: (state is AuthLoading)
                            //     ? _loadingButton()
                            //     : _resetButton(context),
                            child: _submitButton(
                                context, "date_range", _dateFrom, _dateTo),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ));
        });
  }

  MaterialButton _submitButton(
      BuildContext context, String? sortBy, String? fromDate, String? toDate) {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: () {
        // if (sortBy == "largest") {
        //   setState(() {
        //     filter = "total";
        //     _sortType = "DESC";
        //     _loadShimmer = true;
        //   });
        // } else {
        //   setState(() {
        //     filter = "total";
        //     _sortType = "ASC";
        //     _loadShimmer = true;
        //   });
        // }
        switch (sortBy) {
          case "largest":
            setState(() {
              filter = "total";
              _sortType = "DESC";
              _loadShimmer = true;
            });
            break;
          case "smallest":
            setState(() {
              filter = "total";
              _sortType = "ASC";
              _loadShimmer = true;
            });
            break;
          case "newest":
            setState(() {
              filter = "tanggal";
              _sortType = "DESC";
              _loadShimmer = true;
            });
            break;
          case "oldest":
            setState(() {
              filter = "tanggal";
              _sortType = "ASC";
              _loadShimmer = true;
            });
            break;
          case "date_range":
            final form = _key.currentState!;
            if (form.validate()) {
              form.save();
              setState(() {
                filter = "date_range";
                _sortType = "ASC";
                _loadShimmer = true;
                _dateFrom = fromDate;
                _dateTo = toDate;
                print("From : $_dateFrom to : $_dateTo");
              });
            }

            break;
          default:
        }
        getTransaction();
        Navigator.of(context).pop();
        // check();
      },
      color: Colors.blue[200],
      child: Text('Submit', style: TextStyle(color: Colors.white)),
    );
  }
}
