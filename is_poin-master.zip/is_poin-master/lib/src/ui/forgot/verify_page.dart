import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:http/http.dart' as http;
import 'package:animated_background/animated_background.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/ui/forgot/new_password_page.dart';
import 'package:is_poin/src/widgets/custom_dialog.dart';
import 'package:is_poin/src/widgets/custom_loading_button.dart';
import 'package:is_poin/src/widgets/custom_toast_content_widget.dart';
// import 'package:toast/toast.dart';
import 'package:url_launcher/url_launcher.dart';

class VerifyPage extends StatefulWidget {
  final String? _emailObs;
  final String? _kodeCust;
  final String? _email;
  final String? _deviceInfo;
  final int _securityCode;
  VerifyPage(this._emailObs, this._kodeCust, this._email, this._deviceInfo,
      this._securityCode);
  @override
  _VerifyPageState createState() => _VerifyPageState();
}

class _VerifyPageState extends State<VerifyPage> with TickerProviderStateMixin {
  String? _code1 = "", _code2 = "", _code3 = "", _code4 = "";
  int? _verifSec, _verifMin, _verifCode;
  bool isLoading = false, isTimerRun = false, sendLoading = false;
  ApiService _apiService = ApiService();
  GlobalKey<FormState> _verifKey = new GlobalKey<FormState>();
  Timer? _timer;
  String _waUrl =
      "https://api.whatsapp.com/send/?phone=6281380716125&text=Hallo,+saya+ingin+melakukan+reset+password+di+Aplikasi+IS+Point+dan+saat+ini+saya+belum+menerima+security+code+dari+aplikasi,+Apakah+bisa+dibantu%3F&app_absent=0";

  ParticleOptions particleOptions = ParticleOptions(
    baseColor: Colors.blue,
    spawnOpacity: 0.0,
    opacityChangeRate: 0.25,
    minOpacity: 0.1,
    maxOpacity: 0.4,
    spawnMinSpeed: 30.0,
    spawnMaxSpeed: 70.0,
    spawnMinRadius: 7.0,
    spawnMaxRadius: 15.0,
    particleCount: 40,
  );
  newCode() async {
    int timeout = 20;
    String errorTitle = "";
    String? errorMsg = "";
    try {
      // final response = await http.post("${_apiService.apiUrl}login.php", body: {
      final response = await http
          .post(Uri.parse("${_apiService.apiUrl}emailCheck.php"), body: {
        "email_user": widget._email,
        "deviceInfo": widget._deviceInfo,
      }).timeout(Duration(seconds: timeout));
      final data = jsonDecode(response.body);
      int? value = data['value'];
      String? pesan = data['message'];
      print(data);
      if (value == 1) {
        print(pesan);
        setState(() {
          _verifCode = int.parse(data['security_code']);
          sendLoading = false;
        });
        startTimer(60, 1, true);
        isLoading = false;
      } else {
        print(pesan);
        errorTitle = "Email Not Found";
        errorMsg = pesan;
        customDialog(errorTitle, errorMsg, context);
        setState(() {
          isLoading = false;
          sendLoading = false;
        });
      }
    } on TimeoutException catch (e) {
      print('Timeout Error: $e');
      errorTitle = "Connection Timeout";
      errorMsg =
          "The connection has timed out, app server took too long to respond. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg, context);
      setState(() {
        isLoading = false;
        sendLoading = false;
      });
    } on SocketException catch (e) {
      print('Socket Error: $e');
      errorTitle = "Socket Error";
      errorMsg =
          "A socket error occurred during connecting the server. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg, context);
      setState(() {
        isLoading = false;
        sendLoading = false;
      });
    }
    // on Error catch (e) {
    //   print('General Error: $e');
    // }
  }

  check() async {
    final form = _verifKey.currentState!;
    var duration = const Duration(seconds: 1);

    if (form.validate()) {
      form.save();
      int _tempCode;
      _tempCode = int.parse("$_code1$_code2$_code3$_code4");
      print('Temp code : $_tempCode');
      if (_verifMin == 0 && _verifSec == 0) {
        customDialog("Failed",
            "The security code has expired. Please send a new code.", context);
        setState(() {
          isLoading = false;
        });
      } else {
        if (_tempCode == _verifCode) {
          Timer(duration, () {
            Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => NewPasswordPage(widget._kodeCust)));
            // Toast.show('Security code is match!', context,
            //     duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
            showToastWidget(
                CustomToastContentWidget(
                  context: context,
                  msg: "Security code is match!",
                  type: "success",
                  dynWidth: 1.3,
                ),
                context: context,
                position: StyledToastPosition.center,
                animation: StyledToastAnimation.scale,
                reverseAnimation: StyledToastAnimation.scaleRotate,
                duration: Duration(seconds: 3),
                animDuration: Duration(seconds: 1),
                curve: Curves.elasticOut,
                reverseCurve: Curves.easeInOutBack);
          });
        } else {
          customDialog("Failed", "Security code doesn't match!", context);

          setState(() {
            isLoading = false;
          });
        }
      }
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  void startTimer(_startTime, _minute, runTimer) {
    isTimerRun = true;
    const oneMin = const Duration(minutes: 1);
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(oneSec, (Timer timer) {
      if (runTimer == false) {
        timer.cancel();
        isTimerRun = false;
        print('Timer turned off');
      } else {
        if (_startTime == 0) {
          if (_minute == 0) {
            isTimerRun = false;
            timer.cancel();
            print('Timer stopped');
            // setState(() {
            //   _verifCode = 0;
            // });
          }
          _startTime = 60;
          _minute--;
        } else {
          // setState(() {
          setState(() {
            _startTime--;
            _verifSec = _startTime;
            _verifMin = _minute;

            // print("Verif time = $_minute : $_verifSec");
          });
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();
    startTimer(60, 1, true);
    _verifCode = widget._securityCode;
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  void dispose() {
    // if (isTimerRun == true) {
    //   // timer.cancel;
    // }
    startTimer(60, 1, false);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF94B6FF),
                  const Color(0xFF00CCFF),
                ],
                begin: const FractionalOffset(0.0, 1.0),
                end: const FractionalOffset(1.0, 0.0),
                stops: [0.0, 1.0],
                tileMode: TileMode.clamp,
              ),
            ),
          ),
          AnimatedBackground(
            behaviour: RandomParticleBehaviour(options: particleOptions),
            vsync: this,
            child: Container(),
          ),
          Container(
            margin: EdgeInsets.only(top: (!kIsWeb) ? 27 : 0),
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: CustomScrollView(
              slivers: <Widget>[
                SliverList(
                  delegate: SliverChildListDelegate([
                    // TUlisan Hello.
                    Row(
                      children: <Widget>[
                        // SizedBox(width: 16),
                        Expanded(
                            child: Divider(
                          thickness: 3,
                          color: Colors.white,
                        )),
                        SizedBox(width: 5),
                        Text(
                          '.Verify',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 45,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5),
                        ),
                      ],
                    ),
                    Text(
                      'Security code has sent to your email address ${widget._emailObs}',
                      style: TextStyle(
                        color: Colors.grey[200],
                        fontWeight: FontWeight.w400,
                        fontSize: 20,
                        letterSpacing: 3,
                      ),
                    ),
                    SizedBox(height: 30),
                    Form(
                        key: _verifKey,
                        child: Column(children: [
                          // Container(
                          //   child: Text(
                          //     '$_verifCode',
                          //     style: TextStyle(color: Colors.white),
                          //   ),
                          // ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 50,
                                  child: TextFormField(
                                      validator: (e) {
                                        if (e!.isEmpty) {
                                          return "";
                                        }
                                      },
                                      onSaved: (e) => _code1 = e,
                                      key: Key(_code1!),
                                      textAlign: TextAlign.center,
                                      textAlignVertical:
                                          TextAlignVertical.center,
                                      inputFormatters: [
                                        LengthLimitingTextInputFormatter(1)
                                      ],
                                      style: TextStyle(fontSize: 24),
                                      keyboardType: TextInputType.number,
                                      autofocus: true,
                                      // onChanged: (_) => FocusScope.of(context)
                                      //     .nextFocus(), // focus to next,
                                      onChanged: (value) {
                                        if (value.length > 0) {
                                          FocusScope.of(context).nextFocus();
                                        } else {
                                          FocusScope.of(context)
                                              .previousFocus();
                                        }
                                      },
                                      decoration: InputDecoration(
                                        fillColor: Colors.white,
                                        filled: true,
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        contentPadding: EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 15),
                                      )),
                                ),
                                SizedBox(width: 10),
                                Container(
                                  width: 50,
                                  child: TextFormField(
                                      validator: (e) {
                                        if (e!.isEmpty) {
                                          return "";
                                        }
                                      },
                                      onSaved: (e) => _code2 = e,
                                      key: Key(_code2!),
                                      textAlign: TextAlign.center,
                                      textInputAction: TextInputAction.previous,
                                      textAlignVertical:
                                          TextAlignVertical.center,
                                      inputFormatters: [
                                        LengthLimitingTextInputFormatter(1)
                                      ],
                                      style: TextStyle(fontSize: 24),
                                      keyboardType: TextInputType.number,
                                      autofocus: true,
                                      // onChanged: (_) => FocusScope.of(context)
                                      //     .nextFocus(),
                                      onChanged: (value) {
                                        if (value.length > 0) {
                                          FocusScope.of(context).nextFocus();
                                        } else {
                                          FocusScope.of(context)
                                              .previousFocus();
                                        }
                                      },
                                      decoration: InputDecoration(
                                        fillColor: Colors.white,
                                        filled: true,
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        contentPadding: EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 15),
                                      )),
                                ),
                                SizedBox(width: 10),
                                Container(
                                  width: 50,
                                  child: TextFormField(
                                      validator: (e) {
                                        if (e!.isEmpty) {
                                          return "";
                                        }
                                      },
                                      onSaved: (e) => _code3 = e,
                                      key: Key(_code3!),
                                      textAlign: TextAlign.center,
                                      textAlignVertical:
                                          TextAlignVertical.center,
                                      inputFormatters: [
                                        LengthLimitingTextInputFormatter(1)
                                      ],
                                      style: TextStyle(fontSize: 24),
                                      keyboardType: TextInputType.number,
                                      autofocus: true,
                                      // onChanged: (_) => FocusScope.of(context)
                                      //     .nextFocus(), // focus to next,
                                      onChanged: (value) {
                                        if (value.length > 0) {
                                          FocusScope.of(context).nextFocus();
                                        } else {
                                          FocusScope.of(context)
                                              .previousFocus();
                                        }
                                      },
                                      decoration: InputDecoration(
                                        fillColor: Colors.white,
                                        filled: true,
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        contentPadding: EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 15),
                                      )),
                                ),
                                SizedBox(width: 10),
                                Container(
                                  width: 50,
                                  child: TextFormField(
                                      validator: (e) {
                                        if (e!.isEmpty) {
                                          return "";
                                        }
                                      },
                                      onSaved: (e) => _code4 = e,
                                      key: Key(_code4!),
                                      textAlign: TextAlign.center,
                                      textAlignVertical:
                                          TextAlignVertical.center,
                                      inputFormatters: [
                                        LengthLimitingTextInputFormatter(1)
                                      ],
                                      style: TextStyle(fontSize: 24),
                                      keyboardType: TextInputType.number,
                                      autofocus: true,
                                      // onChanged: (_) => FocusScope.of(context)
                                      //     .nextFocus(), // focus to next,
                                      onChanged: (value) {
                                        if (value.length > 0) {
                                          FocusScope.of(context).nextFocus();
                                        } else {
                                          FocusScope.of(context)
                                              .previousFocus();
                                        }
                                      },
                                      decoration: InputDecoration(
                                        fillColor: Colors.white,
                                        filled: true,
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide:
                                              BorderSide(color: Colors.white),
                                        ),
                                        contentPadding: EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 15),
                                      )),
                                ),
                                SizedBox(width: 10),
                              ]),
                          SizedBox(height: 10),
                          Container(
                            child: (_verifSec != null)
                                ? (_verifSec! > 9)
                                    ? Text(
                                        '0${_verifMin.toString()}:${_verifSec.toString()}',
                                        style: TextStyle(color: Colors.white))
                                    : (_verifMin == 0 && _verifSec! < 10)
                                        ? Text(
                                            '0${_verifMin.toString()}:0${_verifSec.toString()}',
                                            style: TextStyle(color: Colors.red))
                                        : Text(
                                            '0${_verifMin.toString()}:0${_verifSec.toString()}',
                                            style:
                                                TextStyle(color: Colors.white))
                                : Container(),
                          ),
                          SizedBox(height: 5),
                          (_verifMin == 0 && _verifSec == 0)
                              ? Row(
                                  // crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      'Your code has expired.',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                    (sendLoading != true)
                                        ? TextButton(
                                            onPressed: () {
                                              newCode();
                                              setState(() {
                                                sendLoading = true;
                                              });
                                            },
                                            child: Text(
                                              'Send new code',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                  decoration:
                                                      TextDecoration.underline,
                                                  decorationThickness: 2),
                                            ))
                                        : Container(
                                            margin: EdgeInsets.only(left: 5),
                                            // color: Colors.red,
                                            width: 30,
                                            height: 30,
                                            child: CupertinoActivityIndicator(),
                                          ),
                                  ],
                                )
                              : Container(),
                          SizedBox(height: 7),
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 8.0),
                            child: Material(
                              borderRadius: BorderRadius.circular(32.0),
                              shadowColor: Colors.black,
                              elevation: 5.0,
                              child: (isLoading == true)
                                  ? _loadingButton()
                                  : _checkButton(context),
                            ),
                          ),
                        ])),
                  ]),
                ),
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Container(
                    // color: Colors.green,
                    alignment: Alignment.bottomCenter,
                    margin: EdgeInsets.only(bottom: 20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "Don't receiving any security code?",
                          style: TextStyle(color: Colors.white),
                        ),
                        SizedBox(height: 2),
                        GestureDetector(
                          onTap: () async {
                            if (await canLaunch(_waUrl)) {
                              await launch(_waUrl, forceSafariVC: false);
                            } else {
                              throw 'Could not launch $_waUrl';
                            }
                          },
                          child: Text(
                            'Contact Admin',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  MaterialButton _checkButton(BuildContext context) {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: () {
        setState(() {
          isLoading = true;
        });
        check();
      },
      color: Color(0xFF4f4f4f),
      child: Text('Submit', style: TextStyle(color: Colors.white)),
    );
  }

  MaterialButton _loadingButton() {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: null,
      color: Colors.black,
      child: CustomLoadingButton(),
    );
  }
}
