import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:http/http.dart' as http;
import 'package:animated_background/animated_background.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/ui/forgot/verify_page.dart';
import 'package:is_poin/src/widgets/custom_dialog.dart';
import 'package:is_poin/src/widgets/custom_loading_button.dart';
import 'package:is_poin/src/widgets/custom_toast_content_widget.dart';
// import 'package:toast/toast.dart';

class NewPasswordPage extends StatefulWidget {
  final String? _kodeCust;
  @override
  _NewPasswordPageState createState() => _NewPasswordPageState();
  NewPasswordPage(this._kodeCust);
}

class _NewPasswordPageState extends State<NewPasswordPage>
    with TickerProviderStateMixin {
  String? _pass = "", _confirmPass = "";
  bool isLoading = false;
  ApiService _apiService = new ApiService();
  GlobalKey<FormState> _newPasKey = new GlobalKey<FormState>();
  int _showPassword = 0;
  bool? _secureText = true;

  String _waUrl =
      "https://api.whatsapp.com/send/?phone=6281380716125&text=Hallo,+saya+ingin+melakukan+reset+password+di+Aplikasi+IS+Point,+Apakah+bisa+dibantu%3F&app_absent=0";
  ParticleOptions particleOptions = ParticleOptions(
    baseColor: Colors.blue,
    spawnOpacity: 0.0,
    opacityChangeRate: 0.25,
    minOpacity: 0.1,
    maxOpacity: 0.4,
    spawnMinSpeed: 30.0,
    spawnMaxSpeed: 70.0,
    spawnMinRadius: 7.0,
    spawnMaxRadius: 15.0,
    particleCount: 40,
  );

  check() {
    final form = _newPasKey.currentState!;
    if (form.validate()) {
      form.save();
      newPassword();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  newPassword() async {
    int timeout = 20;
    String errorTitle = "";
    String? errorMsg = "";
    try {
      // final response = await http.post("${_apiService.apiUrl}login.php", body: {
      final response = await http
          .post(Uri.parse("${_apiService.apiUrl}newPassword.php"), body: {
        "kode_cst": widget._kodeCust,
        "newPassword": _pass,
        "confirmPassword": _confirmPass,
      }).timeout(Duration(seconds: timeout));
      final data = jsonDecode(response.body);
      int? value = data['value'];
      String? pesan = data['message'];
      // String _tempEmail = data['existing_user'][0]['email_obsecure'];
      // int _tempCode = int.parse(data['security_code']);
      // String profilePicture = data['profile_picture'];
      print(data);
      // print("nama $namaAPI");
      if (value == 1) {
        print(pesan);
        // customDialog("Success", "Berhasil", context);
        // Toast.show('Password changed successfuly', context,
        //     duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        showToastWidget(
            CustomToastContentWidget(
              context: context,
              msg: "Password changed successfuly",
              type: "success",
              dynWidth: 1.3,
            ),
            context: context,
            position: StyledToastPosition.center,
            animation: StyledToastAnimation.scale,
            reverseAnimation: StyledToastAnimation.scaleRotate,
            duration: Duration(seconds: 3),
            animDuration: Duration(seconds: 1),
            curve: Curves.elasticOut,
            reverseCurve: Curves.easeInOutBack);

        Navigator.pop(context);
      } else {
        print(pesan);
        errorTitle = "Failed";
        errorMsg = pesan;
        customDialog(errorTitle, errorMsg, context);

        setState(() {
          isLoading = false;
        });
      }
    } on TimeoutException catch (e) {
      print('Timeout Error: $e');
      errorTitle = "Connection Timeout";
      errorMsg =
          "The connection has timed out, app server took too long to respond. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg, context);
      setState(() {
        isLoading = false;
      });
    } on SocketException catch (e) {
      print('Socket Error: $e');
      errorTitle = "Socket Error";
      errorMsg =
          "A socket error occurred during connecting the server. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg, context);
      setState(() {
        isLoading = false;
      });
    }
    // on Error catch (e) {
    //   print('General Error: $e');
    // }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF94B6FF),
                  const Color(0xFF00CCFF),
                ],
                begin: const FractionalOffset(0.0, 1.0),
                end: const FractionalOffset(1.0, 0.0),
                stops: [0.0, 1.0],
                tileMode: TileMode.clamp,
              ),
            ),
          ),
          AnimatedBackground(
            behaviour: RandomParticleBehaviour(options: particleOptions),
            vsync: this,
            child: Container(),
          ),
          Container(
            margin: EdgeInsets.only(top: (!kIsWeb) ? 27 : 0),
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: CustomScrollView(
              slivers: <Widget>[
                SliverList(
                  delegate: SliverChildListDelegate([
                    // TUlisan Hello.
                    Row(
                      children: <Widget>[
                        // SizedBox(width: 16),
                        Expanded(
                            child: Divider(
                          thickness: 3,
                          color: Colors.white,
                        )),
                        SizedBox(width: 5),
                        Text(
                          '.New',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 45,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5),
                        ),
                      ],
                    ),
                    Text(
                      'Enter your new password',
                      style: TextStyle(
                        color: Colors.grey[200],
                        fontWeight: FontWeight.w400,
                        fontSize: 20,
                        letterSpacing: 3,
                      ),
                    ),
                    SizedBox(height: 25),
                    Container(
                        child: Image.asset(
                      'assets/images/password-icon.png',
                      width: 200,
                      height: 200,
                    )),
                    SizedBox(height: 20),
                    Form(
                        key: _newPasKey,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'New Password',
                                style: TextStyle(color: Colors.white),
                              ),
                              SizedBox(height: 8),
                              Container(
                                child: TextFormField(
                                  validator: (e) {
                                    if (e!.isEmpty) {
                                      return "Please insert new password";
                                    }
                                  },
                                  onSaved: (e) => _pass = e,
                                  key: Key(_pass!),
                                  obscureText: _secureText!,
                                  keyboardType: TextInputType.emailAddress,
                                  decoration: InputDecoration(
                                      hintText: 'New Password',
                                      fillColor: Colors.white,
                                      filled: true,
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      focusedErrorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      contentPadding: EdgeInsets.fromLTRB(
                                          10.0, 15.0, 10.0, 15.0),
                                      prefixIcon: Icon(Icons.lock_outline)),
                                ),
                              ),
                              SizedBox(height: 16),
                              Text(
                                'Confirm Password',
                                style: TextStyle(color: Colors.white),
                              ),
                              SizedBox(height: 8),
                              Container(
                                child: TextFormField(
                                  validator: (e) {
                                    if (e!.isEmpty) {
                                      return "Please insert confirm password";
                                    }
                                  },
                                  onSaved: (e) => _confirmPass = e,
                                  key: Key(_confirmPass!),
                                  obscureText: _secureText!,
                                  keyboardType: TextInputType.emailAddress,
                                  decoration: InputDecoration(
                                      hintText: 'Confirm Password',
                                      fillColor: Colors.white,
                                      filled: true,
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      focusedErrorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide:
                                            BorderSide(color: Colors.white),
                                      ),
                                      contentPadding: EdgeInsets.fromLTRB(
                                          10.0, 15.0, 10.0, 15.0),
                                      prefixIcon: Icon(Icons.lock_outline)),
                                ),
                              ),
                              // SizedBox(height: 16),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: StatefulBuilder(builder:
                                        (BuildContext context,
                                            StateSetter setRememberState) {
                                      return Container(
                                        width: 10,
                                        child: CheckboxListTile(
                                          contentPadding: EdgeInsets.all(0),
                                          title: Text(
                                            "Show Password",
                                            style: TextStyle(
                                                fontSize: 14,
                                                color: Colors.white),
                                          ),
                                          value: (_showPassword == 1)
                                              ? true
                                              : false,
                                          onChanged: (bool? newValue) {
                                            setRememberState(() {
                                              _secureText = newValue;

                                              if (_secureText!) {
                                                // print("true");
                                                _showPassword = 1;
                                                setState(() {
                                                  _secureText = false;
                                                });
                                              } else {
                                                // print("false");
                                                _showPassword = 0;
                                                setState(() {
                                                  _secureText = true;
                                                });
                                              }
                                            });
                                          },
                                          activeColor: Color(0xFF4f4f4f),
                                          controlAffinity:
                                              ListTileControlAffinity.leading,
                                        ),
                                      );
                                    }),
                                  ),
                                ],
                              ),

                              Padding(
                                padding: EdgeInsets.symmetric(vertical: 8.0),
                                child: Material(
                                  borderRadius: BorderRadius.circular(32.0),
                                  shadowColor: Colors.black,
                                  elevation: 5.0,
                                  child: (isLoading == true)
                                      ? _loadingButton()
                                      : _checkButton(context),
                                ),
                              ),
                              SizedBox(height: 10)
                            ])),
                  ]),
                ),
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Container(
                    // color: Colors.green,
                    alignment: Alignment.bottomCenter,
                    margin: EdgeInsets.only(bottom: 20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "2021 \u00a9 PT. IS Ing Silver",
                          style: TextStyle(color: Colors.white),
                        ),
                        SizedBox(height: 2),
                        // GestureDetector(
                        //   onTap: () async {},
                        //   child: Text(
                        //     'Contact Admin',
                        //     style: TextStyle(
                        //         color: Colors.white,
                        //         fontWeight: FontWeight.w700),
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  MaterialButton _checkButton(BuildContext context) {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: () {
        setState(() {
          isLoading = true;
        });
        check();
      },
      color: Color(0xFF4f4f4f),
      child: Text('Reset Password', style: TextStyle(color: Colors.white)),
    );
  }

  MaterialButton _loadingButton() {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: null,
      color: Colors.black,
      child: CustomLoadingButton(),
    );
  }
}
