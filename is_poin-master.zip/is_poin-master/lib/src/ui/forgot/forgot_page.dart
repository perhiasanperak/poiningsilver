import 'dart:async';
import 'dart:convert';

import 'dart:io';
import 'package:dart_ipify/dart_ipify.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:animated_background/animated_background.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/ui/forgot/verify_page.dart';
import 'package:is_poin/src/widgets/custom_dialog.dart';
import 'package:is_poin/src/widgets/custom_loading_button.dart';
import 'package:url_launcher/url_launcher.dart';

class ForgotPage extends StatefulWidget {
  @override
  _ForgotPageState createState() => _ForgotPageState();
}

class _ForgotPageState extends State<ForgotPage> with TickerProviderStateMixin {
  String? _email = "", _verifCode, _deviceInfo;
  bool isLoading = false;
  ApiService _apiService = ApiService();
  GlobalKey<FormState> _forgetKey = new GlobalKey<FormState>();
  String _waUrl =
      "https://api.whatsapp.com/send/?phone=6281380716125&text=Hallo,+saya+ingin+melakukan+reset+password+di+Aplikasi+IS+Point,+Apakah+bisa+dibantu%3F&app_absent=0";
  ParticleOptions particleOptions = ParticleOptions(
    baseColor: Colors.blue,
    spawnOpacity: 0.0,
    opacityChangeRate: 0.25,
    minOpacity: 0.1,
    maxOpacity: 0.4,
    spawnMinSpeed: 30.0,
    spawnMaxSpeed: 70.0,
    spawnMinRadius: 7.0,
    spawnMaxRadius: 15.0,
    particleCount: 40,
  );

  getDeviceInfo() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (kIsWeb) {
      WebBrowserInfo webBrowserInfo = await deviceInfo.webBrowserInfo;
      _deviceInfo = webBrowserInfo.userAgent;
      print(webBrowserInfo.userAgent);
    } else if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      _deviceInfo = '${androidInfo.brand!.toUpperCase()} ${androidInfo.model} ';
      // print('Running on ${androidInfo.model}');
      print(_deviceInfo);
    }
    // print('Running on ${androidInfo.brand.toUpperCase()}');
  }

  getIp() async {
    final ipv4 = await Ipify.ipv4();
    print(ipv4); // 98.207.254.136

    final ipv6 = await Ipify.ipv64();
    print(ipv6); // 98.207.254.136 or 2a00:1450:400f:80d::200e

    final ipv4json = await Ipify.ipv64(format: Format.JSON);
    print(ipv4json);
  }

  check() {
    final form = _forgetKey.currentState!;
    if (form.validate()) {
      form.save();
      verifyEmail();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  verifyEmail() async {
    int timeout = 20;
    String errorTitle = "";
    String? errorMsg = "";
    try {
      // final response = await http.post("${_apiService.apiUrl}login.php", body: {
      final response = await http
          .post(Uri.parse("${(_apiService.apiUrl)}emailCheck.php"), body: {
        "email_user": _email,
        "deviceInfo": _deviceInfo,
      }).timeout(Duration(seconds: timeout));
      final data = jsonDecode(response.body);
      int? value = data['value'];
      String? pesan = data['message'];

      print(data);
      // print("nama $namaAPI");
      if (value == 1) {
        String? _tempKodeCust = data['existing_user'][0]['kode_cst'];
        String? _tempEmail = data['existing_user'][0]['email_obsecure'];
        int _tempCode = int.parse(data['security_code']);
        print(pesan);
        Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => VerifyPage(
                  _tempEmail,
                  _tempKodeCust,
                  _email,
                  _deviceInfo,
                  _tempCode,
                )));
        // VerifyPage(this._emailObs, this._kodeCust, this._email, this._deviceInfo, this._securityCode);
        // Toast.show(pesan, context,
        //     duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
        isLoading = false;
      } else {
        print(pesan);
        errorTitle = "Email Not Found";
        errorMsg = pesan;
        customDialog(errorTitle, errorMsg, context);
        setState(() {
          isLoading = false;
        });
      }
    } on TimeoutException catch (e) {
      print('Timeout Error: $e');
      errorTitle = "Connection Timeout";
      errorMsg =
          "The connection has timed out, app server took too long to respond. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg, context);
      setState(() {
        isLoading = false;
      });
    } on SocketException catch (e) {
      print('Socket Error: $e');
      errorTitle = "Socket Error";
      errorMsg =
          "A socket error occurred during connecting the server. Please try again later or check your internet connection";
      customDialog(errorTitle, errorMsg, context);
      setState(() {
        isLoading = false;
      });
    }
    // on Error catch (e) {
    //   print('General Error: $e');
    // }
  }

  @override
  void initState() {
    super.initState();
    getDeviceInfo();
    getIp();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF94B6FF),
                  const Color(0xFF00CCFF),
                ],
                begin: const FractionalOffset(0.0, 1.0),
                end: const FractionalOffset(1.0, 0.0),
                stops: [0.0, 1.0],
                tileMode: TileMode.clamp,
              ),
            ),
          ),
          AnimatedBackground(
            behaviour: RandomParticleBehaviour(options: particleOptions),
            vsync: this,
            child: Container(),
          ),
          Container(
            margin: EdgeInsets.only(top: (!kIsWeb) ? 27 : 0),
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: CustomScrollView(
              slivers: <Widget>[
                SliverList(
                  delegate: SliverChildListDelegate([
                    // TUlisan Hello.
                    Row(
                      children: <Widget>[
                        // SizedBox(width: 16),
                        Expanded(
                            child: Divider(
                          thickness: 3,
                          color: Colors.white,
                        )),
                        SizedBox(width: 5),
                        Text(
                          '.Reset',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 45,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5),
                        ),
                      ],
                    ),
                    Text(
                      'Enter your email address',
                      style: TextStyle(
                        color: Colors.grey[200],
                        fontWeight: FontWeight.w400,
                        fontSize: 20,
                        letterSpacing: 3,
                      ),
                    ),
                    SizedBox(height: 25),
                    // Hero(
                    //   tag: 'hero',
                    //   child: CircleAvatar(
                    //     backgroundColor: Colors.white,
                    //     radius: 60,
                    //     child: Image.asset("assets/images/logo_is.png"),
                    //   ),
                    // ),
                    Container(
                        // width: 100,
                        // height: 100,
                        child: Image.asset(
                      'assets/images/email-verification-email-verify-icon.png',
                      // fit: BoxFit.cover,
                      width: 200,
                      height: 200,
                    )),
                    SizedBox(height: 20),
                    Form(
                        key: _forgetKey,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Email',
                                style: TextStyle(color: Colors.white),
                              ),
                              SizedBox(height: 8),
                              TextFormField(
                                validator: (e) {
                                  if (e!.isEmpty) {
                                    return "Please insert Email";
                                  }
                                },
                                onSaved: (e) => _email = e,
                                key: Key(_email!),
                                autofocus: false,
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(
                                    hintText: 'Email',
                                    fillColor: Colors.white,
                                    filled: true,
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                    ),
                                    errorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                    ),
                                    focusedErrorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                    ),
                                    contentPadding: EdgeInsets.fromLTRB(
                                        10.0, 15.0, 10.0, 15.0),
                                    prefixIcon: Icon(Icons.email_outlined)),
                              ),
                              SizedBox(height: 16),
                              Padding(
                                padding: EdgeInsets.symmetric(vertical: 8.0),
                                child: Material(
                                  borderRadius: BorderRadius.circular(32.0),
                                  shadowColor: Colors.black,
                                  elevation: 5.0,
                                  child: (isLoading == true)
                                      ? _loadingButton()
                                      : _checkButton(context),
                                ),
                              ),
                              SizedBox(height: 10)
                            ])),
                  ]),
                ),
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Container(
                    // color: Colors.green,
                    alignment: Alignment.bottomCenter,
                    margin: EdgeInsets.only(bottom: 20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "Need help?",
                          style: TextStyle(color: Colors.white),
                        ),
                        SizedBox(height: 2),
                        GestureDetector(
                          onTap: () async {
                            if (await canLaunch(_waUrl)) {
                              await launch(_waUrl, forceSafariVC: false);
                            } else {
                              throw 'Could not launch $_waUrl';
                            }
                          },
                          child: Text(
                            'Contact Admin',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  MaterialButton _checkButton(BuildContext context) {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: () {
        setState(() {
          isLoading = true;
        });
        check();
      },
      color: Color(0xFF4f4f4f),
      child: Text('Verification Code', style: TextStyle(color: Colors.white)),
    );
  }

  MaterialButton _loadingButton() {
    return MaterialButton(
      minWidth: double.infinity,
      height: 42.0,
      onPressed: null,
      color: Colors.black,
      child: CustomLoadingButton(),
    );
  }
}
