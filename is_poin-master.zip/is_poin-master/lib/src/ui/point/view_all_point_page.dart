import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:is_poin/src/ui/api/api.dart';
import 'package:is_poin/src/utils/custom_colors.dart';
import 'package:is_poin/src/widgets/custom_loading_indicator.dart';

import 'package:is_poin/src/widgets/list_point_widget.dart';
import 'package:is_poin/src/widgets/list_shimmer_widget.dart';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'dart:convert';
import 'package:http/http.dart' as _http;
import 'package:loading_indicator/loading_indicator.dart';

class ViewAllPointPage extends StatefulWidget {
  final String? custCode;
  ViewAllPointPage({required this.custCode});
  @override
  _ViewAllPointPageState createState() => _ViewAllPointPageState();
}

class _ViewAllPointPageState extends State<ViewAllPointPage> {
  ApiService apiService = ApiService();
  var value;
  String? noNota;
  int? _currentMax = 15,
      offset = 0,
      totalItem = 0,
      itemPerPage = 0,
      itemPerPageTemp = 0;
  List? _listInvoice, _listDate, _listPointNominal, _listNote;
  bool _loadMore = true, _loadShimmer = true;
  List<dynamic>? _listPoint = [];
  CustomColors _customColor = CustomColors();

  ScrollController _scrollController = ScrollController();

  getTransaction() async {
    print("ID VIEW: ${widget.custCode}");
    if (_listInvoice != null) {
      _currentMax = 15;
      offset = 0;
      totalItem = 0;
      itemPerPage = 0;
      itemPerPageTemp = 0;
      _listInvoice!.clear();
      _listDate!.clear();
      _listPointNominal!.clear();
      _listNote!.clear();
      // _listPoint.clear();
    }
    final response = await _http
        .post(Uri.parse("${apiService.apiUrl}getAllPoint.php"), body: {
      "kode_cst": widget.custCode,
      "filter": "",
      "offset": offset.toString()
    });
    final data = jsonDecode(response.body);
    String? _pesan = data['message'];
    int? value = data['value'];
    itemPerPage = data['total_item'];
    totalItem = itemPerPage;
    _listPoint = data['list_point'];
    // noNota = _listPoint[0]["no_nota"];
    if (value == 1) {
      // print(_pesan);
      // print(_listPoint);
      _listInvoice =
          List.generate(itemPerPage!, (i) => _listPoint![i]["no_nota"]);
      // _listInvoice = List.generate(itemPerPage, (i) => i.toString());
      _listDate = List.generate(itemPerPage!, (i) => _listPoint![i]["tanggal"]);
      _listPointNominal =
          List.generate(itemPerPage!, (i) => _listPoint![i]["jumlah_poin"]);
      _listNote =
          List.generate(itemPerPage!, (i) => _listPoint![i]["keterangan"]);
      // print(_listInvoice);
      if (itemPerPage! < 10) {
        _loadMore = false;
      }
      _loadShimmer = false;
    } else {
      print(_pesan);
      _loadShimmer = false;
    }
    setState(() {});
  }

  _getMoreData() async {
    print("Load more data");
    offset = _currentMax;
    final response = await _http
        .post(Uri.parse("${apiService.apiUrl}getAllPoint.php"), body: {
      "kode_cst": widget.custCode,
      "filter": "",
      "offset": offset.toString()
    });
    final data = jsonDecode(response.body);
    String? _pesan = data['message'];
    int? value = data['value'];
    itemPerPage = data['total_item'];
    // print("Item Per Page : $itemPerPage");
    _listPoint = data['list_point'];
    if (value == 1) {
      // print(_pesan);
      totalItem = totalItem! + itemPerPage!;
      // print("Total item : $totalItem");
      if (_listPoint![0]["no_nota"] != null) {
        int j = 0;
        for (int i = _currentMax!; i < _currentMax! + itemPerPage!; i++) {
          _listInvoice!.add(_listPoint![j]["no_nota"]);
          // _listInvoice.add(i.toString());
          _listDate!.add(_listPoint![j]["tanggal"]);
          _listPointNominal!.add(_listPoint![j]["jumlah_poin"]);
          _listNote!.add(_listPoint![j]["keterangan"]);
          j++;
        }
      }
    } else {
      print(_pesan);
      showDialog(
          context: context,
          builder: (BuildContext context) => CupertinoAlertDialog(
                title: new Text("No Item"),
                content: new Text(_pesan!),
                actions: <Widget>[
                  CupertinoDialogAction(
                    child: Text("Close"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ));
      // setState(() {
      _loadMore = false;
      print("Load status : $_loadMore");
    }
    _currentMax = _currentMax! + 15;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    // getPref();
    getTransaction();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        _getMoreData();
      }
    });
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    // print("custCode: ${id}");
    return Stack(
      children: [
        // Container(
        //   color: Colors.black,
        // ),
        Container(
          child: Column(
            children: [
              Container(
                height: 40,
                // color: Colors.red,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      // const Color(0xFF94B6FF),
                      // const Color(0xFF00CCFF),
                      _customColor.gradColor,
                      _customColor.themeColor,
                    ],
                    begin: const FractionalOffset(0.0, 1.0),
                    end: const FractionalOffset(1.0, 0.0),
                    stops: [0.0, 1.0],
                    tileMode: TileMode.clamp,
                  ),
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30)),
                  border: Border.all(
                      width: 1,
                      color: Colors.transparent,
                      style: BorderStyle.solid),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black45,
                        blurRadius: 5,
                        spreadRadius: 1,
                        offset: Offset(0, 5))
                  ],
                ),
                child: Center(
                  child: Text(
                    "POINT HISTORY",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w500),
                  ),
                ),
              ),
              // (noNota != null)?

              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  // decoration: BoxDecoration(
                  //     borderRadius: BorderRadius.circular(20),
                  //     boxShadow: [
                  //       BoxShadow(
                  //           color: Colors.grey[200],
                  //           blurRadius: 10,
                  //           spreadRadius: 1,
                  //           offset: Offset(0, 4))
                  //     ]),
                  child: LiquidPullToRefresh(
                    color: Colors.transparent,
                    backgroundColor: _customColor.gradColor,
                    // animSpeedFactor: 1.0,
                    springAnimationDurationInMilliseconds: 500,
                    showChildOpacityTransition: false,
                    onRefresh: () async {
                      setState(() {
                        _loadShimmer = true;
                      });
                      await getTransaction();
                    },
                    child: SingleChildScrollView(
                        physics: BouncingScrollPhysics(),
                        child: Container(
                          margin: EdgeInsets.only(top: 5),
                          height: MediaQuery.of(context).size.height / 1.22,
                          child: (_loadShimmer == true)
                              ? ListShimmerWidget()
                              : (_listInvoice == null)
                                  ? Container(
                                      child: Center(
                                        child: Text(
                                            "You don't have any transactions yet."),
                                      ),
                                    )
                                  : ListView.builder(
                                      physics: BouncingScrollPhysics(),
                                      itemExtent: 80,
                                      controller: _scrollController,
                                      itemCount: totalItem! + 1,
                                      itemBuilder: (context, i) {
                                        if (i == _listInvoice!.length) {
                                          if (_loadMore == true) {
                                            // return CupertinoActivityIndicator();
                                            return CustomLoadingIndicator();
                                          } else {
                                            return Container();
                                          }
                                        }
                                        return Bounceable(
                                          onTap: () {},
                                          child: Container(
                                            margin: EdgeInsets.only(bottom: 10),
                                            decoration: BoxDecoration(
                                              color: _customColor.listItemCard,
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              // boxShadow: [
                                              //   BoxShadow(
                                              //       color: Colors.grey[50],
                                              //       blurRadius: 1,
                                              //       spreadRadius: 1,
                                              //       offset: Offset(0, 1))
                                              // ],
                                            ),
                                            child: ListPointWidget(
                                              noNota: "${_listInvoice![i]}",
                                              tanggal: "${_listDate![i]}",
                                              point: "${_listPointNominal![i]}",
                                              keterangan: _listNote![i],
                                            ),
                                          ),
                                        );
                                      }),
                        )),
                  ),
                ),
              )
            ],
          ),
        ),
      ],

      // floatingActionButton: FloatingActionButton(
      //   backgroundColor: Colors.blue[200],
      //   splashColor: Colors.blueAccent,
      //   onPressed: () {
      //     return floatingModal(context);
      //   },
      //   tooltip: 'Filter',
      //   child: Icon(
      //     Icons.filter_alt_outlined,
      //     size: 30,
      //     color: Colors.white,
      //   ),
      // ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  Future<void> floatingModal(BuildContext context) {
    return showModalBottomSheet<void>(
        context: context,
        builder: (BuildContext context) {
          return Container(
              color: Colors.grey[200],
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height / 2,
              child: Container(
                child: Column(
                  children: [
                    Text("Filter"),
                  ],
                ),
              ));
        });
  }
}
