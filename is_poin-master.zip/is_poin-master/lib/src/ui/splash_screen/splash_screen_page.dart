import 'dart:async';

import 'package:flutter/material.dart';
import 'package:is_poin/src/ui/login/login_page.dart';
import 'package:shimmer/shimmer.dart';

class SplashScreenPage extends StatefulWidget {
  @override
  _SplashScreenPageState createState() => _SplashScreenPageState();
}

class _SplashScreenPageState extends State<SplashScreenPage> {
  void initState() {
    super.initState();
    startSlpashScreen();
  }

  startSlpashScreen() async {
    var duration = const Duration(seconds: 2);
    return Timer(duration, () {
      // Navigator.of(context)
      //     .pushReplacement(MaterialPageRoute(builder: (context) => Login()));
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => Login(),
          transitionsBuilder: (_, a, __, c) =>
              FadeTransition(opacity: a, child: c),
          transitionDuration: Duration(milliseconds: 1000),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.grey[100],
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 150,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/images/logo_is.png"),
                        fit: BoxFit.contain)),
              ),
              SizedBox(height: 10),
              Shimmer.fromColors(
                baseColor: Colors.black,
                highlightColor: Colors.grey[600]!,
                child: Text(
                  "PT. IS ING SILVER",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
