import 'package:flutter/material.dart';

class NotificationDetailPage extends StatefulWidget {
  final String? notificationId;
  NotificationDetailPage({Key? key, @required this.notificationId})
      : super(key: key);

  @override
  State<NotificationDetailPage> createState() => _NotificationDetailPageState();
}

class _NotificationDetailPageState extends State<NotificationDetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blue[200],
        child: Center(child: Text("${widget.notificationId}")),
      ),
    );
  }
}
