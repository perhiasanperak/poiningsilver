import 'dart:async';

import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:is_poin/src/ui/home/home_page.dart';
import 'package:is_poin/src/ui/home/transaction_detail_page.dart';
import 'package:is_poin/src/ui/notification/notification_detail_page.dart';
import 'package:is_poin/src/ui/point/view_all_point_page.dart';
import 'package:is_poin/src/ui/profile/profile_view_page.dart';
import 'package:is_poin/src/utils/custom_colors.dart';
import 'package:is_poin/src/widgets/custom_toast_content_widget.dart';
import 'package:is_poin/src/widgets/exp_alert_widget.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:shared_preferences/shared_preferences.dart';

GlobalKey<ScaffoldState> _scaffoldState = GlobalKey<ScaffoldState>();

class App extends StatefulWidget {
  static String tag = 'main-menu';

  String? idUser;
  final VoidCallback signOut;

  App(this.signOut, this.idUser);

  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> {
  Timer? _timer;
  int? _expCount;
  CustomColors _customColor = CustomColors();
  bool? _darkModeIsEnabled;
  String? _token, _deviceToken;

  getPref() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      _expCount = preferences.getInt("expCount");
      _darkModeIsEnabled = preferences.getBool("dark_mode");
      _token = preferences.getString('token');
      _deviceToken = preferences.getString('device_token');
      verifyToken();
    });
  }

  void verifyToken() async {
    String? _tempToken = await _token;
    String? _msg = "Token expired, please login again.";
    // handle for user from the old version app (non jwt version)
    if (_tempToken == null || _deviceToken == null) {
      print("sign out");

      showToastWidget(
          CustomToastContentWidget(
              context: context, msg: _msg, type: "failed", dynWidth: 1.3),
          context: context,
          position: StyledToastPosition.center,
          animation: StyledToastAnimation.scale,
          reverseAnimation: StyledToastAnimation.scaleRotate,
          duration: Duration(seconds: 4),
          animDuration: Duration(seconds: 1),
          curve: Curves.elasticOut,
          reverseCurve: Curves.easeInOutBack);
      Future.delayed(const Duration(seconds: 2), () {
        widget.signOut();
      });
    } else {
      bool hasExpired = JwtDecoder.isExpired(_tempToken);

      print("JWT Expired status: $hasExpired");
      if (hasExpired) {
        print("sign out");
        showToastWidget(
            CustomToastContentWidget(
                context: context, msg: _msg, type: "failed", dynWidth: 1.3),
            context: context,
            position: StyledToastPosition.center,
            animation: StyledToastAnimation.scale,
            reverseAnimation: StyledToastAnimation.scaleRotate,
            duration: Duration(seconds: 4),
            animDuration: Duration(seconds: 1),
            curve: Curves.elasticOut,
            reverseCurve: Curves.easeInOutBack);
        Future.delayed(const Duration(seconds: 2), () {
          widget.signOut();
        });
      }
    }
  }

  void startTimer(_startTime) async {
    await getPref();
    print("Expired day: ${_expCount}");
    if (_expCount! >= 0 && _expCount! <= 7) {
      const oneSec = const Duration(seconds: 1);
      _timer = new Timer.periodic(oneSec, (Timer timer) {
        if (_startTime == 0) {
          setState(() {
            print("Expired in : $_expCount days!");
            timer.cancel();
            showDialog(
                barrierDismissible: false,
                context: context,
                builder: (BuildContext context) => CupertinoAlertDialog(
                      title: new Text("Alert"),
                      content: RichText(
                        text: TextSpan(
                          text: "Your points will expire in",
                          style: TextStyle(
                            color: Colors.black,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                                text: ' $_expCount days',
                                style: TextStyle(color: Colors.red)),
                            TextSpan(
                                text:
                                    ". Immediately use your points so they don't expire.",
                                style: TextStyle(color: Colors.black)),
                          ],
                        ),
                      ),
                      actions: <Widget>[
                        CupertinoDialogAction(
                          child: Text("Close"),
                          onPressed: () {
                            Navigator.of(context).pop();
                            startTimer(600); // ? 5 Minutes
                          },
                        ),
                      ],
                    ));
          });
        } else {
          _startTime--;
        }
      });
    }
  }

  @override
  void initState() {
    //? messaging on terminate handler
    FirebaseMessaging.instance.getInitialMessage().then((message) {
      // if (message != null) {
      // Navigator.push(
      //     context,
      //     MaterialPageRoute(
      //         builder: (context) => NotificationDetailPage(
      //             notificationId: message.data['notification_id'])));
      // Navigator.of(context).push(MaterialPageRoute(
      //     builder: (context) =>
      //         TransactionDetailPage(no_nota: message.data['no_nota'])));
      // }
    });
    //? when notification (in notification tray) is clicked when the app on background
    FirebaseMessaging.onMessageOpenedApp.listen((event) {
      // if (event.notification != null) {
      //   Navigator.push(
      //       context,
      //       MaterialPageRoute(
      //           builder: (context) => NotificationDetailPage(
      //               notificationId: event.data['notification_id'])));
      // }
    });

    //? messaging foreground handler
    FirebaseMessaging.onMessage.listen((event) {
      if (event.notification != null) {
        print(event.notification!.title);
      }
    });

    super.initState();
    getPref();
    startTimer(3);
  }

  void handleClick(String value) {
    switch (value) {
      case 'Logout':
        widget.signOut();
        break;
      case 'Settings':
        break;
    }
  }

  int _currentNav = 1;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.black,
        accentColor: Colors.blue[200],
      ),
      home: Scaffold(
          key: _scaffoldState,
          backgroundColor: _customColor.backgroundColor,
          body: SafeArea(
            child: Container(
                child: (_currentNav == 0)
                    ? ViewAllPointPage(custCode: widget.idUser)
                    : (_currentNav == 1)
                        ? HomePage(id: widget.idUser)
                        : ProfileViewPage(widget.idUser)),
          ),
          bottomNavigationBar: ConvexAppBar(
            gradient: LinearGradient(
              colors: [
                _customColor.themeColor,
                _customColor.gradColor,
              ],
              begin: const FractionalOffset(0.0, 1.0),
              end: const FractionalOffset(1.0, 0.0),
              stops: [0.0, 1.0],
              tileMode: TileMode.clamp,
            ),
            color: Colors.grey[200],
            style: TabStyle.reactCircle,
            // cornerRadius: 10, //only work with fixed style
            items: [
              TabItem(icon: Icons.attach_money_rounded, title: 'Point'),
              TabItem(icon: Icons.home_rounded, title: 'Home'),
              TabItem(icon: Icons.person_rounded, title: 'Profile'),
            ],
            initialActiveIndex: 1, //optional, default as 0
            // onTap: (int i) => print('click index=$i'),
            onTap: (index) {
              setState(() {
                _currentNav = index;
              });
            },
          )
          // bottomNavigationBar: BottomNavigationBar(
          //   showUnselectedLabels: false,
          //   currentIndex: _currentNav,
          //   type: BottomNavigationBarType.fixed,
          //   items: [
          //     BottomNavigationBarItem(
          //       icon: Icon(
          //         Icons.home,
          //         color: Colors.blue[200],
          //       ),
          //       title: Text("Home"),
          //     ),
          //     BottomNavigationBarItem(
          //       icon: Icon(Icons.person_outline, color: Colors.blue[200]),
          //       title: Text("Account"),
          //     )
          //   ],
          //   onTap: (index) {
          //     setState(() {
          //       _currentNav = index;
          //     });
          //   },
          // ),
          // drawer: _buildDrawer(),
          ),
    );
  }

  // Widget _buildDrawer() {
  //   return SizedBox(
  //     // width: MediaQuery.of(context).size.width / 1.5,
  //     width: 250,
  //     child: Drawer(
  //       child: new ListView(
  //         padding: EdgeInsets.zero,
  //         children: <Widget>[
  //           UserAccountsDrawerHeader(
  //             accountName: Text(widget.telp),
  //             accountEmail: Text(widget.email),
  //             currentAccountPicture: CircleAvatar(
  //               backgroundColor: Colors.white,
  //               radius: 5,
  //               child: Image.network(
  //                   'https://d32ogoqmya1dw8.cloudfront.net/images/serc/empty_user_icon_256.v2.png'),
  //             ),
  //             decoration: BoxDecoration(color: Colors.black),
  //           ),
  //           new ListTile(
  //             title: new Text("Home"),
  //             leading: Icon(Icons.home),
  //             onTap: () {},
  //           ),
  //           new ListTile(
  //             title: new Text("Account"),
  //             leading: Icon(Icons.person),
  //             onTap: () {},
  //           ),
  //           Divider(
  //             height: 2.0,
  //             color: Colors.grey,
  //           ),
  //           new ListTile(
  //             title: new Text("About"),
  //             leading: Icon(Icons.announcement),
  //             onTap: () {},
  //           ),
  //           new ListTile(
  //             title: new Text("Logout"),
  //             leading: Icon(Icons.input),
  //             onTap: () {
  //               widget.signOut();
  //               // Toast.show("Berhasil logout!", context,
  //               //     duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
  //             },
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }
}
