import 'package:flutter/material.dart';
import 'package:loading_indicator/loading_indicator.dart';

class CustomLoadingIndicator extends StatelessWidget {
  const CustomLoadingIndicator({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.red,
      height: 30,
      width: 100,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 130, vertical: 20),
        child: LoadingIndicator(
          indicatorType: Indicator.lineScale,
          colors: const [
            Colors.red,
            Colors.blue,
            Colors.green,
            Colors.yellow,
            Colors.purple,
          ],
          strokeWidth: 1,
        ),
      ),
    );
  }
}
