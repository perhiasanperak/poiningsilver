import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Future customDialog(String errorTitle, String? errorMsg, BuildContext context) {
  return showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
            title: new Text(errorTitle),
            content: new Text(errorMsg!),
            actions: <Widget>[
              CupertinoDialogAction(
                // isDefaultAction: false,
                child: Text("Close"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ));
}
