import 'package:flutter/material.dart';
import 'package:is_poin/src/utils/custom_colors.dart';

CustomColors _colors = CustomColors();

class ListPointWidget extends StatelessWidget {
  const ListPointWidget(
      {Key? key,
      required this.noNota,
      required this.tanggal,
      required this.point,
      required this.keterangan})
      : super(key: key);

  final String noNota, tanggal, point;
  final int? keterangan;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      height: 65,
      alignment: Alignment.center,
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                noNota,
                style: TextStyle(
                  color: _colors.textColorHighlight,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                tanggal,
                style: TextStyle(
                    color: Colors.grey[500], fontWeight: FontWeight.w500),
              ),
            ],
          ),
          Spacer(),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              (keterangan == 0)
                  ? Text(
                      // (point == "0") ? "test" : point + " Pts",
                      point + " Pts",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.red[700],
                        fontWeight: FontWeight.w500,
                      ),
                    )
                  : Text(
                      // (point == "0") ? "test" : point + " Pts",
                      point + " Pts",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.green[700],
                        fontWeight: FontWeight.w500,
                      ),
                    )
            ],
          ),
        ],
      ),
    );
  }
}
