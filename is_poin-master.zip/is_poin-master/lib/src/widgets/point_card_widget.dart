import 'package:flutter/material.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:is_poin/src/ui/home/view_barcode.dart';
import 'package:shimmer/shimmer.dart';
import 'package:syncfusion_flutter_barcodes/barcodes.dart';

class PointCardWIdget extends StatelessWidget {
  const PointCardWIdget(
      {Key? key,
      required String? id,
      required String? rpPoin,
      required String? name,
      required String? expPoin,
      required Color gradColor,
      required Color themeColor})
      : _id = id,
        _rpPoin = rpPoin,
        _name = name,
        _expPoin = expPoin,
        _gradColor = gradColor,
        _themeColor = themeColor,
        super(key: key);

  final String? _id;
  final String? _rpPoin;
  final String? _name;
  final String? _expPoin;
  final Color _gradColor;
  final Color _themeColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      child: Container(
        height: 230,
        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 30),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _gradColor,
              _themeColor
              // const Color(0xFF0C54F0),
              // const Color(0xFF000000),
            ],
            begin: const FractionalOffset(0.0, 1.0),
            end: const FractionalOffset(1.0, 0.0),
            stops: [0.0, 1.0],
            tileMode: TileMode.clamp,
          ),
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
                color: Colors.black45,
                blurRadius: 10,
                spreadRadius: 1,
                offset: Offset(0, 4))
          ],
        ),
        child: Column(
          children: [
            Container(
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("ING SILVER POINT",
                      style: TextStyle(
                        letterSpacing: 1,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        // fontFamily: "JetBrainsMono",
                      )),
                  Spacer(),
                  Image.asset(
                    "assets/images/logo_is.png",
                    color: Colors.white,
                    fit: BoxFit.fitWidth,
                    width: 70,
                    // height: 90,
                  ),
                ],
              ),
            ),
            Container(
              height: 70,
              width: double.infinity,
              alignment: Alignment.centerLeft,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 150,
                    height: 50,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Material(
                          color: Colors.transparent,
                          child: Bounceable(
                            onTap: () {
                              modalDetail(context, _id);
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Container(
                                    width: 100,
                                    height: 40,
                                    child: SfBarcodeGenerator(
                                      barColor: Colors.white,
                                      textStyle: TextStyle(color: Colors.white),
                                      value: '${_id}',
                                      // symbology: QR,
                                      showValue: true,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Container(
                      alignment: Alignment.centerRight,
                      child: (_rpPoin != null)
                          ? Text(
                              // _rpPoin + " Pts",
                              "$_rpPoin Pts",

                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            )
                          : Shimmer.fromColors(
                              baseColor: Colors.blue[200]!,
                              highlightColor: Colors.grey[200]!,
                              child: Container(
                                width: 120,
                                height: 20,
                                color: Colors.blue[200],
                                // color: Colors.red,
                              ),
                            )),
                ],
              ),
            ),
            SizedBox(height: 5),
            Flexible(
              child: Container(
                height: 65,
                alignment: Alignment.center,
                padding: EdgeInsets.only(top: 13),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 175,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "NAME",
                            style: TextStyle(fontSize: 12, color: Colors.white),
                          ),
                          (_name != null)
                              ? Flexible(
                                  child: Text(
                                    // "KEVIN LAURENCE H.",
                                    "${_name!.toUpperCase()}",
                                    style: TextStyle(
                                        letterSpacing: 2,
                                        fontSize: 16,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 2,
                                  ),
                                )
                              : Shimmer.fromColors(
                                  baseColor: Colors.blue[200]!,
                                  highlightColor: Colors.grey[200]!,
                                  child: Container(
                                    width: 120,
                                    height: 20,
                                    color: Colors.blue[200],
                                  ),
                                )
                        ],
                      ),
                    ),
                    Spacer(),
                    Container(
                      width: 80,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "EXPIRY",
                            style: TextStyle(fontSize: 12, color: Colors.white),
                          ),
                          Flexible(
                              child: (_expPoin != null)
                                  ? Text(
                                      // "01/01/2022",
                                      "$_expPoin",
                                      style: TextStyle(
                                          letterSpacing: 1,
                                          fontSize: 13,
                                          color: Colors.white),
                                    )
                                  : Shimmer.fromColors(
                                      baseColor: Colors.blue[200]!,
                                      highlightColor: Colors.grey[200]!,
                                      child: Container(
                                        width: 120,
                                        height: 20,
                                        color: Colors.blue[200],
                                      ),
                                    ))
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
