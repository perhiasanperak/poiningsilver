import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';

class CustomToastContentWidget extends StatelessWidget {
  const CustomToastContentWidget({
    Key? key,
    required this.context,
    required this.msg,
    required this.type,
    required this.dynWidth,
  }) : super(key: key);

  final BuildContext context;
  final String? msg;
  final String? type;
  final double? dynWidth;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Container(
        width: MediaQuery.of(context).size.width / dynWidth!,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
        decoration: BoxDecoration(
          color: Colors.black45,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              (type == 'success')
                  ? LineIcons.checkCircleAlt
                  : LineIcons.exclamationCircle,
              color: Colors.white,
              size: 30,
            ),
            SizedBox(width: 5),
            Flexible(
              child: Text(
                "$msg",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
    // return Padding(
    //   padding: const EdgeInsets.symmetric(horizontal: 10),
    //   child: SizedBox(

    //     child: Container(
    //       // width: MediaQuery.of(context).size.width / 2,
    //       // height: 70,

    //       padding: EdgeInsets.symmetric(horizontal: 30),
    //       alignment: Alignment.center,
    //       decoration: BoxDecoration(
    //           color: Colors.black45, borderRadius: BorderRadius.circular(20)),
    //       child: Text(
    //         msg!,
    //         style: TextStyle(
    //             color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
    //       ),
    //       // child: Row(
    //       //   mainAxisAlignment: MainAxisAlignment.center,
    //       //   crossAxisAlignment: CrossAxisAlignment.center,
    //       //   children: [
    //       //     Icon(
    //       //       (type == 'success')
    //       //           ? LineIcons.checkCircleAlt
    //       //           : LineIcons.exclamationCircle,
    //       //       color: Colors.white,
    //       //       size: 30,
    //       //     ),
    //       //     SizedBox(width: 5),
    //       //     Text(
    //       //       msg!,
    //       //       style: TextStyle(
    //       //           color: Colors.white,
    //       //           fontWeight: FontWeight.bold,
    //       //           fontSize: 16),
    //       //     ),
    //       //   ],
    //       // ),
    //     ),
    //   ),
    // );
  }
}
