import 'package:flutter/material.dart';
import 'package:is_poin/src/utils/custom_colors.dart';
import 'package:shimmer/shimmer.dart';

CustomColors _customColor = CustomColors();

class ListShimmerWidget extends StatelessWidget {
  const ListShimmerWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: 9,
      itemBuilder: (context, i) => Container(
        margin: EdgeInsets.only(bottom: 10),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        height: 69,
        alignment: Alignment.center,
        child: Shimmer.fromColors(
          baseColor: Colors.grey[200]!,
          highlightColor: Colors.white,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 100,
                    height: 20,
                    color: Colors.grey[200],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Container(
                    width: 100,
                    height: 20,
                    color: Colors.grey[200],
                  ),
                ],
              ),
              Spacer(),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 120,
                    height: 20,
                    color: Colors.grey[200],
                  ),
                ],
              )
            ],
          ),
        ),
        decoration: BoxDecoration(
          color: _customColor.listItemCard,
          borderRadius: BorderRadius.circular(15),
          // boxShadow: [
          //   BoxShadow(
          //       color: Colors.grey[50],
          //       blurRadius: 1,
          //       spreadRadius: 1,
          //       offset: Offset(0, 1))
          // ],
        ),
      ),
    );
  }
}
