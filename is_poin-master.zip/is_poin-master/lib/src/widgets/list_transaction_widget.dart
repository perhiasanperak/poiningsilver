import 'package:flutter/material.dart';
import 'package:is_poin/src/utils/custom_colors.dart';

CustomColors _colors = CustomColors();

class ListTransactionWidget extends StatelessWidget {
  const ListTransactionWidget(
      {Key? key,
      required this.noNota,
      required this.tanggal,
      required this.totalTrans})
      : super(key: key);

  final String? noNota;
  final String? tanggal;

  final String? totalTrans;
  @override
  Widget build(BuildContext context) {
    // print("COlor: ${_colors.textColorHighlight}");
    return Container(
      // color: Colors.red,
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      height: 65,
      alignment: Alignment.center,
      child: Container(
        // color: Colors.red,
        child: Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  noNota!,
                  style: TextStyle(
                    color: _colors.textColorHighlight,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    // fontFamily: 'JetBrainsMono',
                  ),
                ),
                Text(
                  tanggal!,
                  style: TextStyle(
                      color: Colors.grey[500], fontWeight: FontWeight.w500),
                ),
              ],
            ),
            Spacer(),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Rp $totalTrans",
                  style: TextStyle(
                    color: _colors.textColorHighlight,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    // fontFamily: 'JetBrainsMono'
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
