import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void expAlertWidget(BuildContext context) {
  showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
            title: new Text("Alert"),
            content: RichText(
              text: TextSpan(
                text: "Your points will expire in",
                style: TextStyle(
                  color: Colors.black,
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: ' 0 days', style: TextStyle(color: Colors.red)),
                  TextSpan(
                      text:
                          ". Immediately use your points so they don't expire.",
                      style: TextStyle(color: Colors.black)),
                ],
              ),
            ),
            actions: <Widget>[
              CupertinoDialogAction(
                child: Text("Close"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ));
}
